package com.example.finalapps;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.content.Intent;

import androidx.test.espresso.intent.rule.IntentsTestRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
public class LoginActivityTest {


    @Test
    public void testLoginUserSuccess() {

        IntentsTestRule<LoginActivity> activity = new IntentsTestRule<>(LoginActivity.class);
        activity.launchActivity(new Intent());

        // Set up test data
        String username = "m";
        String password = "password";

        onView(withId(R.id.login_logo)).check(matches(isDisplayed()));
        onView(withId(R.id.login_username)).check(matches(isDisplayed()));
        onView(withId(R.id.login_password_input)).check(matches(isDisplayed()));
        onView(withId(R.id.login_Button)).check(matches(isDisplayed()));
        onView(withId(R.id.admin_login_button)).check(matches(isDisplayed()));


        // Enter the login details
        onView(withId(R.id.login_username)).perform(typeText(username), closeSoftKeyboard());
        onView(withId(R.id.login_password_input)).perform(typeText(password), closeSoftKeyboard());

    }
}