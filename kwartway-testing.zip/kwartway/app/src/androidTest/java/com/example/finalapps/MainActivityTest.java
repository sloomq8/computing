package com.example.finalapps;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import android.content.Intent;

import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.intent.rule.IntentsTestRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Test
    public void testclick_button_login() {

        IntentsTestRule<MainActivity> activity = new IntentsTestRule<>(MainActivity.class);
        activity.launchActivity(new Intent());

        onView(withId(R.id.loginButton)).check(matches(isDisplayed()));
        // Enter the login details
        onView(withId(R.id.loginButton)).perform(click());

        Intents.release();
    }

    @Test
    public void testclick_button_join() {

        IntentsTestRule<MainActivity> activity = new IntentsTestRule<>(MainActivity.class);
        activity.launchActivity(new Intent());

        onView(withId(R.id.joinNowButton)).check(matches(isDisplayed()));
        // Enter the login details
        onView(withId(R.id.joinNowButton)).perform(click());

        Intents.release();
    }
}
