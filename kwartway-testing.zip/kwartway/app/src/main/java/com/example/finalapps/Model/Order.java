package com.example.finalapps.Model;

import java.util.ArrayList;
import java.util.Date;

public class Order {
    String orderId,userId;
    Date orderDate;
    ArrayList<Cart> cartList;
    ShipmentDetail shipmentDetail;
    double finalBill;

    public Order() {
    }

    public Order(String orderId, String userId, Date orderDate, ArrayList<Cart> cartList, ShipmentDetail shipmentDetail, double finalBill) {
        this.orderId = orderId;
        this.userId = userId;
        this.orderDate = orderDate;
        this.cartList = cartList;
        this.shipmentDetail = shipmentDetail;
        this.finalBill = finalBill;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public double getFinalBill() {
        return finalBill;
    }

    public void setFinalBill(double finalBill) {
        this.finalBill = finalBill;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public ArrayList<Cart> getCartList() {
        return cartList;
    }

    public void setCartList(ArrayList<Cart> cartList) {
        this.cartList = cartList;
    }

    public ShipmentDetail getShipmentDetail() {
        return shipmentDetail;
    }

    public void setShipmentDetail(ShipmentDetail shipmentDetail) {
        this.shipmentDetail = shipmentDetail;
    }
}
