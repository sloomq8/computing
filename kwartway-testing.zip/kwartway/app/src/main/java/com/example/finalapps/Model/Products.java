package com.example.finalapps.Model;

import java.util.Objects;

public class Products
{
    private String category, name, image, price,rent, salePrice, description, productId, date, time,
    code,quantity;
    boolean ifDiscounted;



    public Products()
    {

    }

    public Products(String category, String name, String image, String price, String salePrice, String description, String productId, String date, String time, String code, String quantity, boolean ifDiscounted) {
        this.category = category;
        this.name = name;
        this.image = image;
        this.price = price;
        this.rent = rent;
        this.salePrice = salePrice;
        this.description = description;
        this.productId = productId;
        this.date = date;
        this.time = time;
        this.code = code;
        this.quantity = quantity;
        this.ifDiscounted = ifDiscounted;
    }

    public String getRent() {
        return rent;
    }

    public void setRent(String rent) {
        this.rent = rent;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public boolean isIfDiscounted() {
        return ifDiscounted;
    }

    public void setIfDiscounted(boolean ifDiscounted) {
        this.ifDiscounted = ifDiscounted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Products products = (Products) o;
        return ifDiscounted == products.ifDiscounted && Objects.equals(category, products.category) && Objects.equals(name, products.name) && Objects.equals(image, products.image) && Objects.equals(price, products.price) && Objects.equals(rent, products.rent) && Objects.equals(salePrice, products.salePrice) && Objects.equals(description, products.description) && Objects.equals(productId, products.productId) && Objects.equals(date, products.date) && Objects.equals(time, products.time) && Objects.equals(code, products.code) && Objects.equals(quantity, products.quantity);
    }

    @Override
    public int hashCode() {
        return Objects.hash(category, name, image, price, rent, salePrice, description, productId, date, time, code, quantity, ifDiscounted);
    }

    @Override
    public String toString() {
        return "Products{" +
                "name='" + name + '\'' +
                ", productId='" + productId + '\'' +
                '}';
    }
}
