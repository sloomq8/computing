package com.example.finalapps;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.applozic.mobicomkit.api.account.register.RegistrationResponse;
import com.example.finalapps.Model.Products;
import com.example.finalapps.Prevalent.Prevalent;
import com.example.finalapps.ui.home.CartFragment;
import com.example.finalapps.ui.home.CartFragment2;
import com.example.finalapps.ui.home.HomeFragment;
import com.example.finalapps.ui.home.HomeViewModel;
import com.example.finalapps.ui.home.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;

import de.hdodenhof.circleimageview.CircleImageView;
import io.kommunicate.KmConversationBuilder;
import io.kommunicate.KmConversationHelper;
import io.kommunicate.Kommunicate;
import io.kommunicate.callbacks.KMLoginHandler;
import io.kommunicate.callbacks.KmCallback;
import io.kommunicate.users.KMUser;
import io.paperdb.Paper;

public class HomeActivity extends AppCompatActivity implements
        NavigationView.OnNavigationItemSelectedListener {

    private static final String TAG = "HomeActivity";
    private FragmentContainerView frameLayout;

    public static String type = "";
    private BottomNavigationView bottom_navigation;
    private DrawerLayout drawerLayout;
    Deque<Integer> integerDeque = new ArrayDeque<>(4);
    boolean flag = true;
    ArrayList<Products> idList = new ArrayList<>();

    private EditText searchEditText;
    private ProgressDialog progressDialog;
    private HomeViewModel homeViewModel;
    public static DrawerLayout drawer_layout;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        drawer_layout = findViewById(R.id.drawer_layout);

        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);




        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        if (bundle != null) {
            //type = getIntent().getExtras().get("Admin").toString();

        }
        type = LoginActivity.type;

        Paper.init(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        searchEditText = findViewById(R.id.searchEditText);
        drawerLayout = findViewById(R.id.drawer_layout);


        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.toString().length() < 1) {
                    homeViewModel.setQuery("");
                    return;
                }
                homeViewModel.setQuery(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!type.equals("Admin")) {
                    Intent intent = new Intent(HomeActivity.this, CartActivity.class);
                    startActivity(intent);
                }
            }
        });


        Kommunicate.init(this, "38173a6e141bc762358c6a1856142c0a8");

        KMUser user = new KMUser();
        user.setUserId(Prevalent.currentOnlineUser.getPhone());
        user.setUserName(Prevalent.currentOnlineUser.getUsername());
        user.setEmail(Prevalent.currentOnlineUser.getEmail());
        user.setImageLink(Prevalent.currentOnlineUser.getImage());


        Kommunicate.login(this, user, new KMLoginHandler() {
            @Override
            public void onSuccess(RegistrationResponse registrationResponse, Context context) {
                Log.d(TAG, "onSuccess: " + registrationResponse.toString());
            }

            @Override
            public void onFailure(RegistrationResponse registrationResponse, Exception exception) {
                Log.d(TAG, "onFailure: " + exception.getMessage());
            }
        });

        Kommunicate.loginAsVisitor(this, new KMLoginHandler() {
            @Override
            public void onSuccess(RegistrationResponse registrationResponse, Context context) {
                Log.d(TAG, "onSuccess: " + registrationResponse.toString());
            }

            @Override
            public void onFailure(RegistrationResponse registrationResponse, Exception exception) {
                Log.d(TAG, "onFailure: " + exception.getMessage());
            }
        });

        progressDialog = new ProgressDialog(HomeActivity.this);
        progressDialog.setTitle("Loading");
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);

        FloatingActionButton fab2 = findViewById(R.id.fab_chat);
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progressDialog.show();

                new KmConversationBuilder(HomeActivity.this)
                        .setSingleConversation(false)
                        .createConversation(new KmCallback() {
                            @Override
                            public void onSuccess(Object message) {
                                String conversationId = message.toString();
                                openConversation(Integer.parseInt(conversationId));
                            }

                            @Override
                            public void onFailure(Object error) {
                                Log.d("ConversationTest", "Error : " + error);
                            }
                        });
            }
        });

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_sort_24);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View headerView = navigationView.getHeaderView(0);
        TextView userNameTextView = headerView.findViewById(R.id.user_profile_name);
        CircleImageView userImageView = headerView.findViewById(R.id.user_profile_image);

        frameLayout = findViewById(R.id.parentContainer);

        if (!type.equals("Admin")) {
            userNameTextView.setText(Prevalent.currentOnlineUser.getUsername());
            Picasso.get().load(Prevalent.currentOnlineUser.getImage()).placeholder(R.mipmap.ic_launcher_round).into(userImageView);

        } else {
            userNameTextView.setText(Prevalent.currentOnlineUser.getUsername());
            Picasso.get().load(Prevalent.currentOnlineUser.getImage()).placeholder(R.mipmap.ic_launcher_round).into(userImageView);

            // Picasso.get().load(Prevalent.currentOnlineUser.getImage()).placeholder(R.mipmap.ic_launcher_round).into(userImageView);

        }

        //..................................
        bottom_navigation = findViewById(R.id.bottom_navigation);
        bottom_navigation.setItemIconTintList(null);
//        bottom_navigation.setSelectedItemId(R.id.home);

        //  loadFragment(new HomeFragment());
        bottom_navigation.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.profile:
                    return setFragment(new ProfileFragment());
                case R.id.favourite:
                    return setFragment(new CartFragment2());
                case R.id.cart:
                    return setFragment(new CartFragment());
                default:
                    return setFragment(new HomeFragment());
            }
        });

        getSupportFragmentManager().addFragmentOnAttachListener((fragmentManager, fragment) -> {
            homeViewModel.setSearchVisibility(fragment.getClass().equals(HomeFragment.class));
        });
        homeViewModel.searchVisibility.observe(this, aBoolean -> {
            if (aBoolean) {
                searchEditText.setVisibility(View.VISIBLE);
            } else {
                searchEditText.setVisibility(View.GONE);
            }
        });
        homeViewModel.fabVisibility.observe(this, aBoolean -> {
            if (aBoolean) {
                fab.setVisibility(View.VISIBLE);
                fab2.setVisibility(View.VISIBLE);
            } else {
                fab.setVisibility(View.GONE);
                fab2.setVisibility(View.GONE);
            }
        });

        getSupportFragmentManager().addFragmentOnAttachListener((fragmentManager, fragment) -> {
            if (fragment.getClass().equals(HomeFragment.class)) {
                searchEditText.setVisibility(View.VISIBLE);
            } else {
                searchEditText.setVisibility(View.GONE);

            }
        });
    }

    private void openConversation(int conversationId) {
        try {
            KmConversationHelper.openConversation(this,
                    true,
                    conversationId,
                    new KmCallback() {
                        @Override
                        public void onSuccess(Object message) {
                            progressDialog.dismiss();
                        }

                        @Override
                        public void onFailure(Object error) {

                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.main_search_icon) {
            return true;
        } else if (id == R.id.main_settings_icon) {
//            return true;
            if (!type.equals("Admin")) {
                Intent callIntent = new Intent(Intent.ACTION_CALL); //use ACTION_CALL class
                callIntent.setData(Uri.parse("tel:+96566660779"));    //this is the phone number calling
                //check permission
                //If the device is running Android 6.0 (API level 23) and the app's targetSdkVersion is 23 or higher,
                //the system asks the user to grant approval.
                if (ActivityCompat.checkSelfPermission(HomeActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    //request permission from user if the app hasn't got the required permission
                    ActivityCompat.requestPermissions(HomeActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE},   //request specific permission from user
                            10);
                } else {     //have got permission
                    try {
                        startActivity(callIntent);  //call activity and make phone call
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(getApplicationContext(), "yourActivity is not founded", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        drawerLayout.closeDrawer(GravityCompat.START);
        int id = item.getItemId();
        switch (id) {
            case R.id.nav_home:
                setFragment(new HomeFragment());
                bottom_navigation.setSelectedItemId(R.id.home);
                break;
            case R.id.nav_cart:
                if (!type.equals("Admin")) {
                    setFragment(new CartFragment());
                    bottom_navigation.setSelectedItemId(R.id.cart);
                }
                break;
            case R.id.nav_tools:
                if (!type.equals("Admin")) {
                    setFragment(new ProfileFragment());
                    bottom_navigation.setSelectedItemId(R.id.profile);
                }
                break;
            case R.id.nav_logout:
                Paper.book().destroy();
                Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
                break;
        }
        return true;
    }

    public Boolean setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(frameLayout.getId(), fragment);
        fragmentTransaction.commit();
        return true;
    }
}