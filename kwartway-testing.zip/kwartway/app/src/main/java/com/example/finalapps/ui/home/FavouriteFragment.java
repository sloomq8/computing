package com.example.finalapps.ui.home;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalapps.CartActivity;
import com.example.finalapps.Model.Cart;
import com.example.finalapps.Prevalent.Prevalent;
import com.example.finalapps.ProductDetailsActivity;
import com.example.finalapps.R;
import com.example.finalapps.ViewHolder.CartViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class FavouriteFragment extends Fragment {

    private RecyclerView recycleView;
    private RecyclerView.LayoutManager layoutManager;

    private TextView txtTotalAmount,cart_heading;

    double totalAmount=0.0;
    private Button Continue, Negotiate;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.favourite_fragment, container, false);

        recycleView = view.findViewById(R.id.fav_List);
        recycleView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        recycleView.setLayoutManager(layoutManager);
        cart_heading=view.findViewById(R.id.cart_heading);
        setCart_heading();

        //......................................................
        final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Fav List1");

        FirebaseRecyclerOptions<Cart> options =
                new FirebaseRecyclerOptions.Builder<Cart>()
                        .setQuery(cartListRef.child("User View")
                                .child(Prevalent.currentOnlineUser.getUsername())
                                .child("Products"), Cart.class)
                        .build();


        FirebaseRecyclerAdapter<Cart, CartViewHolder> adapter =
                new FirebaseRecyclerAdapter<Cart, CartViewHolder>(options)
                {
                    @Override
                    protected void onBindViewHolder(@NonNull CartViewHolder holder, int position, @NonNull final Cart model)
                    {

                        holder.txtProductQuantity.setText("x " + model.getQuantity());
                        holder.txtProductRent.setText("Rent: " + model.getRent());
                        Picasso.get().load(model.getImage()).into(holder.cartImage);
                        holder.txtProductName.setText(model.getProductName());
                        if(model.isIfDiscounted())
                        {
                            holder.txtProductPrice.setText(model.getProductSalePrice());
                        }
                        else
                        {
                            holder.txtProductPrice.setText(model.getProductPrice());
                        }
//                        double oneTypeProductPrice = ((Integer.valueOf(model.getProductSalePrice()))) * (Integer.valueOf(model.getQuantity()));
//                        overTotalPrice = overTotalPrice + oneTypeProductPrice;

                        holder.itemView.setOnClickListener(new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View view)
                            {
                                CharSequence options[] = new CharSequence[]
                                        {
                                                "Edit",
                                                "Remove"
                                        };
                                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                builder.setTitle("Cart Options");

                                builder.setItems(options, new DialogInterface.OnClickListener()
                                {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i)
                                    {
                                        if (i == 0)
                                        {
                                            Intent intent = new Intent(getActivity(), ProductDetailsActivity.class);
                                            intent.putExtra("productId", model.getProductId());
                                            startActivity(intent);
                                            setCart_heading();
                                        }
                                        if (i == 1)
                                        {
                                            cartListRef.child("User View")
                                                    .child(Prevalent.currentOnlineUser
                                                            .getUsername()).child("Products")
                                                    .child(model.getProductId())
                                                    .removeValue()
                                                    .addOnCompleteListener(new OnCompleteListener<Void>()
                                                    {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task)
                                                        {
                                                            if (task.isSuccessful())
                                                            {
                                                                Toast.makeText(getActivity(), "Item removed from fav", Toast.LENGTH_SHORT).show();
                                                                Intent intent = new Intent(getActivity(), CartActivity.class);
                                                                startActivity(intent);
                                                            }
                                                        }
                                                    });
                                            setCart_heading();
                                        }
                                    }
                                });
                                builder.show();
                            }
                        });
                    }

                    @NonNull
                    @Override
                    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
                    {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item_layout, parent, false);
                        CartViewHolder holder = new CartViewHolder(view);
                        return holder;
                    }
                };

        recycleView.setAdapter(adapter);
        adapter.startListening();
        //......................................................

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onStart()
    {
        super.onStart();

       /* final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Fav List1");

        FirebaseRecyclerOptions<Cart> options =
                new FirebaseRecyclerOptions.Builder<Cart>()
                        .setQuery(cartListRef.child("User View")
                                .child(Prevalent.currentOnlineUser.getUsername())
                                .child("Products"), Cart.class)
                        .build();


        FirebaseRecyclerAdapter<Cart, CartViewHolder> adapter =
                new FirebaseRecyclerAdapter<Cart, CartViewHolder>(options)
                {
                    @Override
                    protected void onBindViewHolder(@NonNull CartViewHolder holder, int position, @NonNull final Cart model)
                    {

                        holder.txtProductQuantity.setText("x " + model.getQuantity());
                        Picasso.get().load(model.getImage()).into(holder.cartImage);
                        holder.txtProductName.setText(model.getProductName());
                        if(model.isIfDiscounted())
                        {
                            holder.txtProductPrice.setText(model.getProductSalePrice());
                        }
                        else
                        {
                            holder.txtProductPrice.setText(model.getProductPrice());
                        }
//                        double oneTypeProductPrice = ((Integer.valueOf(model.getProductSalePrice()))) * (Integer.valueOf(model.getQuantity()));
//                        overTotalPrice = overTotalPrice + oneTypeProductPrice;

                        holder.itemView.setOnClickListener(new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View view)
                            {
                                CharSequence options[] = new CharSequence[]
                                        {
                                                "Edit",
                                                "Remove"
                                        };
                                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                builder.setTitle("Cart Options");

                                builder.setItems(options, new DialogInterface.OnClickListener()
                                {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i)
                                    {
                                        if (i == 0)
                                        {
                                            Intent intent = new Intent(getActivity(), ProductDetailsActivity.class);
                                            intent.putExtra("productId", model.getProductId());
                                            startActivity(intent);
                                            setCart_heading();
                                        }
                                        if (i == 1)
                                        {
                                            cartListRef.child("User View")
                                                    .child(Prevalent.currentOnlineUser
                                                            .getUsername()).child("Products")
                                                    .child(model.getProductId())
                                                    .removeValue()
                                                    .addOnCompleteListener(new OnCompleteListener<Void>()
                                                    {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task)
                                                        {
                                                            if (task.isSuccessful())
                                                            {
                                                                Toast.makeText(getActivity(), "Item removed from fav", Toast.LENGTH_SHORT).show();
                                                                Intent intent = new Intent(getActivity(), CartActivity.class);
                                                                startActivity(intent);
                                                            }
                                                        }
                                                    });
                                            setCart_heading();
                                        }
                                    }
                                });
                                builder.show();
                            }
                        });
                    }

                    @NonNull
                    @Override
                    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
                    {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item_layout, parent, false);
                        CartViewHolder holder = new CartViewHolder(view);
                        return holder;
                    }
                };

        recycleView.setAdapter(adapter);
        adapter.startListening();*/
    }
    public void setCart_heading() {
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Fav List1").child("User View").child(Prevalent.currentOnlineUser.getUsername());
        reference.child("Products").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Cart> list=new ArrayList<>();
                for (DataSnapshot postshot : snapshot.getChildren()) {
                    Cart cart = postshot.getValue(Cart.class);
                    list.add(cart);
                }

                //Double totalAmount=0.0;
                for(int i=0;i<list.size();i++)
                {
                    Cart c=list.get(i);
                    if(c.isIfDiscounted())
                    {
                        totalAmount+=(Double.parseDouble(list.get(i).getProductSalePrice().substring(0,list.get(i).getProductSalePrice().length()-1))*Double.parseDouble(list.get(i).getQuantity()));
                    }
                    else
                    {
                        totalAmount+=(Double.parseDouble(list.get(i).getProductPrice().substring(0,list.get(i).getProductPrice().length()-1))*Double.parseDouble(list.get(i).getQuantity()));
                    }


                }
                cart_heading.setText("Total Price : "+totalAmount+"$");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
