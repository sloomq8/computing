package com.example.finalapps.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.finalapps.Model.Order;
import com.example.finalapps.R;
import com.example.finalapps.ViewHolder.orderAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminNewOrdersActivity extends AppCompatActivity
{
    private RecyclerView orderList;
    private DatabaseReference orderRef;
    private ArrayList<Order> orderListArray;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        orderListArray=new ArrayList<>();
        setContentView(R.layout.activity_admin_new_orders);
        orderRef = FirebaseDatabase.getInstance().getReference().child("Orders");
        orderList = findViewById(R.id.order_list);
        orderList.setLayoutManager(new LinearLayoutManager(this));
        orderAdapter adapter=new orderAdapter(AdminNewOrdersActivity.this,orderListArray);
        orderList.setAdapter(adapter);
        orderRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot postshot : snapshot.getChildren()) {
                    Order order = postshot.getValue(Order.class);
                    orderListArray.add(order);
                }
                orderAdapter adapter=new orderAdapter(AdminNewOrdersActivity.this,orderListArray);
                orderList.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    @Override
    protected void onStart()
    {
        super.onStart();

    }
}