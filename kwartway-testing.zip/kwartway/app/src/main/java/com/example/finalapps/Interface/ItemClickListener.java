package com.example.finalapps.Interface;

import android.view.View;

import com.example.finalapps.Model.Products;

public interface ItemClickListener
{
    void onClick(Products product);
    default void fabClick(Products product){};
}
