package com.example.finalapps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalapps.Admin.adminCategoryActivity;
import com.example.finalapps.Model.Users;
import com.example.finalapps.Prevalent.Prevalent;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import io.paperdb.Paper;

public class LoginActivity extends AppCompatActivity
{
    private EditText input_Username, inputPassword;
    private Button loginButton, admin_button,loginToSignup;
    private ProgressDialog loadingBar;
    private CheckBox checkBoxRememberMe;
    private TextView forgotPasswordLink;

    private String parentDBName = "Users";

    public static String type = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginButton = (Button) findViewById(R.id.login_Button);
        input_Username = (EditText) findViewById(R.id.login_username);
        inputPassword = (EditText) findViewById(R.id.login_password_input);
        admin_button = (Button) findViewById(R.id.admin_login_button);
        forgotPasswordLink = (TextView) findViewById(R.id.forgot_password_link);
        loginToSignup = (Button) findViewById(R.id.login_to_signup);

        loadingBar = new ProgressDialog(this);

        checkBoxRememberMe = (CheckBox) findViewById(R.id.remember_me_checkBox);

        Paper.init(this);

        loginToSignup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(LoginActivity.this, registerActivity.class);
                startActivity(intent);
                finish();
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });



        admin_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                loginButton.setText("Login Admin");
                admin_button.setVisibility(View.INVISIBLE);
                parentDBName = "Admins";

            }
        });
    }

    private void loginUser()
    {
        String username = input_Username.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username))
        {
            Toast.makeText(this, "Please Enter your Username...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(password))
        {
            Toast.makeText(this, "Please Enter your Password...", Toast.LENGTH_SHORT).show();
        }

        else {

            loadingBar.show();
            loadingBar.setContentView(R.layout.login_progress_dialog);
            loadingBar.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            loadingBar.setCanceledOnTouchOutside(false);

            allowAccessToAccount(username, password);
        }
    }

    private void allowAccessToAccount(final String username, final String password)
    {
        if (checkBoxRememberMe.isChecked())
        {
            Paper.book().write(Prevalent.userUsernameKey, username);
            Paper.book().write(Prevalent.userPasswordKey, password);
        }


        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();

        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

              if (snapshot.child(parentDBName).child(username).exists())
                {
                    Users usersData = snapshot.child(parentDBName).child(username).getValue(Users.class);

                    assert usersData != null;

                    if (usersData.getUsername().equals(username))
                    {
                        if (usersData.getPassword().equals(password))
                        {
//                            Toast.makeText(loginActivity.this, "Logged in Successfully...", Toast.LENGTH_SHORT).show();
//                            Intent intent = new Intent(loginActivity.this, HomeActivity.class);
//                            startActivity(intent);
                            if (parentDBName.equals("Admins"))
                            {
                                Toast.makeText(LoginActivity.this, "Welcome Admin, You're logged in Successfully...", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(LoginActivity.this, adminCategoryActivity.class);
                                //intent.putExtra("Admin","Admin");
                                Prevalent.currentOnlineUser = usersData;
                                type="Admin";
                                startActivity(intent);
                            }
                            else if (parentDBName.equals("Users"))
                            {
                                Toast.makeText(LoginActivity.this, "Logged in Successfully...", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                Prevalent.currentOnlineUser = usersData;
                                type="";
                                startActivity(intent);
                            }

                            finish();
                        }

                        else
                            {
                            loadingBar.dismiss();
                            Toast.makeText(LoginActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                else {
                    Toast.makeText(LoginActivity.this, "Account with " + username + " does not exist...", Toast.LENGTH_SHORT).show();
                    Toast.makeText(LoginActivity.this, "You need to create an account", Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    protected void onDestroy() {
        loadingBar.cancel();
        loadingBar = null;
        super.onDestroy();
    }
}