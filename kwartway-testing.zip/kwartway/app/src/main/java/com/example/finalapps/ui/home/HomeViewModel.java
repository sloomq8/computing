package com.example.finalapps.ui.home;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.example.finalapps.Model.Products;

import org.apache.commons.collections4.ListUtils;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveChannel<Boolean> _snackbarEvent = new MutableLiveChannel<>();
    public LiveChannel<Boolean> snackbarEvent = _snackbarEvent;

    public void setStateSnackbar(boolean abool){
        _snackbarEvent.setValue(abool);
    }

    private final MutableLiveData<List<Products>> _allItem = new MutableLiveData<>();

    private final MutableLiveData<Products> _currentItem = new MutableLiveData<>();
    public final LiveData<Products> currentItem = _currentItem;

    public void updateItems(List<Products> products) {
        _allItem.postValue(products);
    }


    public void updateCurrent(Products products) {
        _currentItem.postValue(products);
    }

    private final MutableLiveData<String> _query = new MutableLiveData<>("");

    public void setQuery(String query) {
        _query.postValue(query);
    }

    public final LiveData<List<Products>> allItem =
            Transformations.switchMap(_query, s -> {
                try {
                    if (s.isEmpty()) return Transformations.map(_allItem, input -> {
                        if (input == null) return Collections.emptyList();
                        else return input;
                    });

                    return Transformations.map(_allItem,
                            items -> ListUtils.select(items, ele -> {
                                if (ele != null && ele.getName() != null)
                                    return ele.getName().matches("(?i).*" + s + ".*");
                                return false;
                            }));
                } catch (Exception e) {
                    e.printStackTrace();
                    return new MutableLiveData<List<Products>>(Collections.emptyList());
                }
            });

    private final MutableLiveData<Boolean> _searchVisibility = new MutableLiveData<>();
    public LiveData<Boolean> searchVisibility = _searchVisibility;
    public void setSearchVisibility(boolean b) {
        _searchVisibility.postValue(b);
    }

    private final MutableLiveData<Boolean> _fabVisility = new MutableLiveData<>();
    public LiveData<Boolean> fabVisibility = _searchVisibility;
    public void setFabVisible(boolean b) {
        _fabVisility.postValue(b);
    }

}
class MutableLiveChannel<T> extends LiveChannel<T>{

    public MutableLiveChannel(T value) {
        super(value);
    }

    /**
     * Creates a MutableLiveData with no value assigned to it.
     */
    public MutableLiveChannel() {
        super();
    }

    @Override
    public void postValue(T value) {
        super.postValue(value);
    }

    @Override
    public void setValue(T value) {
        super.setValue(value);
    }
}

class LiveChannel<T> extends LiveData<T> {

    public LiveChannel(T value) {
        super(value);
    }

    public LiveChannel() {}

    private static final String TAG = "SingleLiveEvent";

    private final AtomicBoolean mPending = new AtomicBoolean(false);

    @MainThread
    public void observe(@NonNull LifecycleOwner owner, @NonNull Observer<? super T> observer) {
        if (hasActiveObservers()) {
            Log.w(TAG, "Multiple observers registered but only one will be notified of changes.");
        }
        // Observe the internal MutableLiveData
        super.observe(owner, t -> {
            if (mPending.compareAndSet(true, false)) {
                observer.onChanged(t);
            }
        });
    }

    @MainThread
    public void setValue(@Nullable T t) {
        mPending.set(true);
        super.setValue(t);
    }

    /**
     * Used for cases where T is Void, to make calls cleaner.
     */
    @MainThread
    public void call() {
        setValue(null);
    }
}