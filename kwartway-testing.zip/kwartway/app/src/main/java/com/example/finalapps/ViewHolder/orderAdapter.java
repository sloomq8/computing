package com.example.finalapps.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalapps.Model.Cart;
import com.example.finalapps.Model.Order;
import com.example.finalapps.R;

import java.util.ArrayList;

public class orderAdapter extends RecyclerView.Adapter<orderAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<Order> orderList;

    public orderAdapter(Context context, ArrayList<Order> orderList) {
        this.context = context;
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.orders_layout, parent, false);
        return new orderAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            Order order=orderList.get(position);
            ArrayList<Cart> cartList=order.getCartList();
            double totalAmount=0.0;
            for(int i=0;i<cartList.size();i++)
            {
                totalAmount+=(Double.parseDouble(cartList.get(i).getProductSalePrice().substring(0,cartList.get(i).getProductPrice().length()-1))*Double.parseDouble(cartList.get(i).getQuantity()));
            }

            holder.name.setText(order.getUserId());
            holder.phoneNo.setText(order.getShipmentDetail().getPhone());
            holder.address.setText(order.getShipmentDetail().getAddress());
            holder.dateTime.setText(order.getOrderDate().toString());
            holder.price.setText("$"+totalAmount+"");
            holder.orderViewBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //you can do your further work from here
                }
            });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView name,phoneNo,price,address,dateTime;
        Button orderViewBtn;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.order_customer_name);
            phoneNo=itemView.findViewById(R.id.order_phone_no);
            price=itemView.findViewById(R.id.order_total_price);
            address=itemView.findViewById(R.id.order_address);
            dateTime=itemView.findViewById(R.id.orde_date_time);
            orderViewBtn=itemView.findViewById(R.id.order_view_btn);
        }


    }
}