package com.example.finalapps.Model;

public class Slider
{
    private int banner;


    public Slider(int banner)
    {
        this.banner = banner;
    }

    public int getBanner()
    {
        return banner;
    }

    public void setBanner(int banner)
    {
        this.banner = banner;
    }
}
