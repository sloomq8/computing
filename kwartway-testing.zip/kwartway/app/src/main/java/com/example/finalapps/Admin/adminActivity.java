package com.example.finalapps.Admin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
//import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.finalapps.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class adminActivity extends AppCompatActivity
{
    private String CategoryName, ProductName, ProductPrice,ProductRent,ProductSalePrice, ProductDescription,
    productCode,productQuantity;

    private String saveCurrentDate, saveCurrentTime;
    private String productRandomKey, downloadImageUrl;

    private Button AddNewProduct;

    private ImageView productImage;

    private EditText product_name, product_price,rent_price, product_sale_price, product_description,
    product_quantity, product_code;

    private CheckBox ifDiscounted;

    private static final int galleryPicture = 1;

    private Uri imageUri;

    private StorageReference ProductImagesRef;

    private DatabaseReference ProductsRef;

    private ProgressDialog loadingBar;

    //product code, name of product, description, how much left from this product and image.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        CategoryName = "all";

        ProductImagesRef = FirebaseStorage.getInstance().getReference().child("Product Images");

        ProductsRef = FirebaseDatabase.getInstance().getReference().child("Products");

        AddNewProduct = (Button) findViewById(R.id.add_new_product);
        productImage = (ImageView) findViewById(R.id.select_product_image);
        product_name = (EditText) findViewById(R.id.product_name);
        product_price = (EditText) findViewById(R.id.product_price);
        rent_price = (EditText) findViewById(R.id.product_rent_price);
        product_sale_price = (EditText) findViewById(R.id.product_sale_price);
        product_description = (EditText) findViewById(R.id.product_description);
        ifDiscounted = (CheckBox) findViewById(R.id.ifdiscounted_checkBox);
        product_code = findViewById(R.id.product_code);
        product_quantity = findViewById(R.id.product_quantity);


        loadingBar = new ProgressDialog(this);

        productImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                openGallery();
            }
        });

        AddNewProduct.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view)
            {
                validateProductData();
            }
        });

    }

    private void openGallery()
    {
        Intent galleryIntent = new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, galleryPicture);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == galleryPicture && resultCode == RESULT_OK && data != null)
        {
            imageUri = data.getData();
            productImage.setImageURI(imageUri);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void validateProductData()
    {
        productCode  = product_code.getText().toString();
        ProductName = product_name.getText().toString();
        ProductPrice = product_price.getText().toString();
        ProductRent = rent_price.getText().toString();
        productQuantity  = product_quantity.getText().toString();
        ProductDescription = product_description.getText().toString();
        // ProductSalePrice = product_sale_price.getText().toString();

        if (imageUri == null)
        {
            Toast.makeText(this, "Image is required...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(ProductName))
        {
            Toast.makeText(this, "Product Name is required...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(productCode))
        {
            Toast.makeText(this, "Product Code is required...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(ProductPrice))
        {
            Toast.makeText(this, "Product Price is required...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(ProductRent))
        {
            Toast.makeText(this, "Product Rent Price is required...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(productQuantity))
        {
            Toast.makeText(this, "Product Quantity is required...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(ProductDescription))
        {
            Toast.makeText(this, "Product Description is required...", Toast.LENGTH_SHORT).show();
        }

        else
        {
            storeProductInformation();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void storeProductInformation()
    {

        loadingBar.setTitle("Adding New Product");
        loadingBar.setMessage("Please wait, product is being added...");
        loadingBar.setCanceledOnTouchOutside(false);
        loadingBar.show();

        Calendar calendar = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy");
        saveCurrentDate = currentDate.format(calendar.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z");
        saveCurrentTime = currentTime.format(calendar.getTime());

        productRandomKey = saveCurrentDate + saveCurrentTime;

        final StorageReference filePath = ProductImagesRef.child(imageUri.getLastPathSegment() + productRandomKey + ".jpg");

        final UploadTask uploadTask = filePath.putFile(imageUri);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e)
            {
                String message = e.toString();
                Toast.makeText(adminActivity.this, "Error" + message, Toast.LENGTH_SHORT).show();
                loadingBar.dismiss();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
            {
                Toast.makeText(adminActivity.this, "Product image uploaded Successfully...", Toast.LENGTH_SHORT).show();

                Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception
                    {
                        if (!task.isSuccessful())
                        {
                            throw task.getException();
                        }

                        downloadImageUrl = filePath.getDownloadUrl().toString();
                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task)
                    {
                        if (task.isSuccessful())
                        {
                            downloadImageUrl = task.getResult().toString();

                            Toast.makeText(adminActivity.this, "getting Product image URL Successfully...", Toast.LENGTH_SHORT).show();

                            saveProductInfoToDatabase();
                        }
                    }
                });
            }
        });
    }

    private void saveProductInfoToDatabase()
    {
        HashMap<String, Object> productMap = new HashMap<>();
        productMap.put("productId", productRandomKey);
        productMap.put("date", saveCurrentDate);
        productMap.put("time", saveCurrentTime);
        productMap.put("description", ProductDescription);
        productMap.put("image", downloadImageUrl);
        productMap.put("category", CategoryName);
        productMap.put("price", ProductPrice);
        productMap.put("salePrice", ProductPrice);
        productMap.put("rent", ProductRent);
        productMap.put("name", ProductName);
        productMap.put("code", productCode);
        productMap.put("quantity", productQuantity);
        productMap.put("ifDiscounted",ifDiscounted.isChecked());
        ProductsRef.child(productRandomKey).updateChildren(productMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task)
                    {
                        if(task.isSuccessful())
                        {
                            Intent intent = new Intent(adminActivity.this, adminCategoryActivity.class);
                            startActivity(intent);

                            loadingBar.dismiss();
                            Toast.makeText(adminActivity.this, "Product added successfully...", Toast.LENGTH_SHORT).show();
                        }

                        else
                        {
                            loadingBar.dismiss();
                            String message = task.getException().toString();
                            Toast.makeText(adminActivity.this, "Error: " + message, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}