package com.example.finalapps;

public class Constants {
    public static String AVAILABLE = "available";
    public static String UNAVAILABLE = "unavailable";
    public static String VEHICLEDATABASE = "Vehicles";
    public static String ORDERDEVILVERD = "delivered";
    public static String ORDERNOTDEVILVERD = "not delivered";
    public static String COMPLETEDEVILVERD = "complete";
    public static String INCOMPLETEDEVILVERD = "incomplete";


    public static String PAYPAL_CLIENT_ID = "AZQ2j72misD_NKo4TAodEKB8GL4sCgRdKWbL00HRPa3QkGPwshmVhZupKmXqntJJ6Bh2EFY3MOt2W1gh";

    public static String PAYPAL_SECRET = "EIycO8ZHk4hlNqvlwyQE7zkYWjUvcJHKdHhEOw_ht5nnQrYaqk4ALwH-WrkbFkNGXdUQcW7-fjZV5A9p";
}
