package com.example.finalapps;

import android.app.Application;

import com.paypal.checkout.PayPalCheckout;
import com.paypal.checkout.config.CheckoutConfig;
import com.paypal.checkout.config.Environment;
import com.paypal.checkout.createorder.CurrencyCode;
import com.paypal.checkout.createorder.UserAction;

/**
 * Created by kishon on 16,March,2023
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Initialize the SDK
        PayPalCheckout.setConfig(
                new CheckoutConfig(
                        this,
                        Constants.PAYPAL_CLIENT_ID,
                        Environment.SANDBOX,
                        CurrencyCode.USD,
                        UserAction.PAY_NOW,
                        BuildConfig.APPLICATION_ID + "://paypalpay"
                )
        );
    }
}
