package com.example.finalapps;

import static android.R.color;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finalapps.Model.Users;
import com.example.finalapps.Prevalent.Prevalent;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class MainActivity extends AppCompatActivity {

    private Button joinNowButton, loginButton;


    private ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        joinNowButton = (Button) findViewById(R.id.joinNowButton);
        loginButton = (Button) findViewById(R.id.loginButton);

        loadingBar = new ProgressDialog(this);

        Paper.init(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        joinNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, registerActivity.class);
                startActivity(intent);
                finish();
            }
        });

        String userUsernameKey = Paper.book().read(Prevalent.userUsernameKey);
        String userPasswordKey = Paper.book().read(Prevalent.userPasswordKey);

        if (!Objects.equals(userUsernameKey, "") && !Objects.equals(userPasswordKey, "")) {
            if (!TextUtils.isEmpty(userUsernameKey) && !TextUtils.isEmpty(userPasswordKey)) {
                allowAccess(userUsernameKey, userPasswordKey);

                loadingBar = new ProgressDialog(MainActivity.this);
                loadingBar.show();
                loadingBar.setContentView(R.layout.main_progress_dialog);
                loadingBar.getWindow().setBackgroundDrawableResource(color.transparent);

            }
        }

    }

    private void allowAccess(final String username, final String password) {
        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();

        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.child("Users").child(username).exists()) {
                    Users usersData = snapshot.child("Users").child(username).getValue(Users.class);

                    assert usersData != null;
                    if (usersData.getPassword().equals(password)) {
                        LoginActivity.type = "";
                        Toast.makeText(MainActivity.this, "You are already logged in...", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                        Prevalent.currentOnlineUser = usersData;
                        startActivity(intent);
                        finish();
                    } else {
                        loadingBar.dismiss();
                        Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Account with " + username + "does not exist...", Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, "You need to create an account", Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        loadingBar.cancel();
        loadingBar = null;
    }
}