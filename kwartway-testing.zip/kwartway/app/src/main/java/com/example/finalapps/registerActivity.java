package com.example.finalapps;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class registerActivity extends AppCompatActivity {

    private Button createAccountButton, signupToLogin;
    private EditText inputFirstName,inputUserName, inputLastName,inputAddress, inputEmail, inputPhone, inputPassword;
    private ProgressDialog loadingBar;
    FirebaseAuth UserAuth;

    private String saveCurrentDate, saveCurrentTime;
    private String profileRandomKey, downloadImageUrl;

    private static final int galleryPicture = 1;

    CircleImageView profileImage;

    private Uri imageUri;
    int i = 0;

    private StorageReference profileImagesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        createAccountButton = (Button) findViewById(R.id.register_button);
        profileImage = findViewById(R.id.select_profile_image);
        inputUserName = (EditText) findViewById(R.id.register_username_edit);
        inputFirstName = (EditText) findViewById(R.id.register_name);
        inputLastName = (EditText) findViewById(R.id.register_username);
        inputAddress = (EditText) findViewById(R.id.register_address);
        inputEmail = (EditText) findViewById(R.id.register_email);
        inputPhone = (EditText) findViewById(R.id.register_phone);
        inputPassword = (EditText) findViewById(R.id.register_password);
        signupToLogin = (Button) findViewById(R.id.signup_to_login);
        loadingBar = new ProgressDialog(this);

        profileImagesRef = FirebaseStorage.getInstance().getReference().child("Profile Images");

        signupToLogin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(registerActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        UserAuth = FirebaseAuth.getInstance();

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view)
            {
                ValidateAllInfo();
            }
        });
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGallery();
            }
        });
    }

    private void openGallery()
    {
        Intent galleryIntent = new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, galleryPicture);
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void storeProfilePicture(final String username,final String firstName,final String lastName,final String address,final String email,final String password,final String phone)
    {

        loadingBar.setTitle("Adding New User");
        loadingBar.setMessage("Please wait, user is being added...");
        loadingBar.setCanceledOnTouchOutside(false);
        loadingBar.show();


        saveProfileInfoToDatabase(username,firstName,lastName,address,email,phone,password,"downloadImageUrl");

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void ValidateAllInfo()
    {
        String username = inputUserName.getText().toString().trim();
        String firstName = inputFirstName.getText().toString();
        String lastName = inputLastName.getText().toString();
        String address = inputAddress.getText().toString();
        String email = inputEmail.getText().toString();
        String phone = inputPhone.getText().toString();
        String password = inputPassword.getText().toString().trim();

     //   first name, last name, mail, password, address city, phone number and circle image view.

//        Input Data Validation

         if (TextUtils.isEmpty(username))
        {
            Toast.makeText(this, "Please Enter your username...", Toast.LENGTH_SHORT).show();
        }
         else if (TextUtils.isEmpty(firstName))
        {
            Toast.makeText(this, "Please Enter your firstName...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(lastName))
        {
            Toast.makeText(this, "Please Enter your lastName...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(address))
        {
            Toast.makeText(this, "Please Enter your address...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(email))
        {
            Toast.makeText(this, "Please Enter your Email...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(phone))
        {
            Toast.makeText(this, "Please Enter your Phone...", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(password))
        {
            Toast.makeText(this, "Please Enter your Password...", Toast.LENGTH_SHORT).show();
        }
        else if (password.length()<=7)
        {
            Toast.makeText(this, "Password length is minimum 8 characters", Toast.LENGTH_SHORT).show();
        }

        else {

            loadingBar.show();
            loadingBar.setContentView(R.layout.login_progress_dialog);
            loadingBar.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            loadingBar.setCanceledOnTouchOutside(false);

          //  validateUsername(name, username, email, phone, password,);
             storeProfilePicture(username,firstName,lastName,address,email,password,phone);
        }

    }

    /*private boolean validateEmailname(final String email)
    {

        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();

        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!(snapshot.child("Users").child(firstName).exists()))
                {
                    i = 1;
                }
                else
                    {
                        i = 0;
                        Toast.makeText(registerActivity.this, "This email" + email + "already exists", Toast.LENGTH_SHORT).show();
                        loadingBar.dismiss();
                        Toast.makeText(registerActivity.this, "Please Try again using another username", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(registerActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                i = 0;
            }
        });

        if(i==1)
        {
            return true;
        }else
        {
            return  false;
        }
    }*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == galleryPicture && resultCode == RESULT_OK && data != null)
        {
            imageUri = data.getData();
            profileImage.setImageURI(imageUri);
        }
    }

    private void saveProfileInfoToDatabase(final String username,final String firstName,final String lastName, final String address, final String email, final String phone, final String password,String downloadImageUrl)
    {
        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();
        HashMap<String, Object> userDataMap = new HashMap<>();
        userDataMap.put("image", downloadImageUrl);
        userDataMap.put("username", username);
        userDataMap.put("firstname", firstName);
        userDataMap.put("lastName", lastName);
        userDataMap.put("address", address);
        userDataMap.put("email", email);
        userDataMap.put("phone", phone);
        userDataMap.put("password", password);



        RootRef.child("Users").child(username).updateChildren(userDataMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(registerActivity.this, "Account Created Successfully...", Toast.LENGTH_SHORT).show();
                            loadingBar.dismiss();

                            Intent intent = new Intent(registerActivity.this, LoginActivity.class);
                            startActivity(intent);
                        }
                        else
                        {
                            loadingBar.dismiss();
                            Toast.makeText(registerActivity.this, "Network Error, Check Your Internet connection and Try again in a while...", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }



}