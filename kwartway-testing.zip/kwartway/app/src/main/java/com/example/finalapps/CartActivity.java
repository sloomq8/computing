package com.example.finalapps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalapps.Model.Cart;
import com.example.finalapps.Prevalent.Prevalent;
import com.example.finalapps.ViewHolder.CartViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity
{

    private RecyclerView recycleView;
    private RecyclerView.LayoutManager layoutManager;

    private TextView txtTotalAmount,cart_heading;

    double totalAmount=0.0;
    double totalRent=0.0;
    private Button Continue, Negotiate,Rent;
    public static ArrayList<Cart> list;

//    private double overTotalPrice = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        recycleView = (RecyclerView) findViewById(R.id.cart_List);
        recycleView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recycleView.setLayoutManager(layoutManager);
        cart_heading=findViewById(R.id.cart_heading);
        Continue = (Button) findViewById(R.id.continue_to_checkout);
        Rent = (Button) findViewById(R.id.continue_to_rent);
        Negotiate = (Button) findViewById(R.id.negotiate);
        setCart_heading();

//        txtTotalAmount = (TextView) findViewById(R.id.total_price);

        Continue.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(CartActivity.this, ConfirmFinalOrderActivity.class);
                intent.putExtra("totalAmount",totalAmount);
                ConfirmFinalOrderActivity.isBuy = true;
                startActivity(intent);
            }
        });
        Rent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(CartActivity.this, ConfirmFinalOrderActivity.class);
                intent.putExtra("totalAmount",totalRent);
                ConfirmFinalOrderActivity.isBuy = false;
                startActivity(intent);
            }
        });

       /* Negotiate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(CartActivity.this, ChatActivity.class);
                intent.putExtra("totalAmount",totalAmount);
                startActivity(intent);
            }
        });*/
        Negotiate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent callIntent = new Intent(Intent.ACTION_CALL); //use ACTION_CALL class
                callIntent.setData(Uri.parse("tel:+96566660779"));    //this is the phone number calling
                //check permission
                //If the device is running Android 6.0 (API level 23) and the app's targetSdkVersion is 23 or higher,
                //the system asks the user to grant approval.
                if (ActivityCompat.checkSelfPermission(CartActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    //request permission from user if the app hasn't got the required permission
                    ActivityCompat.requestPermissions(CartActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE},   //request specific permission from user
                            10);
                    return;
                }else {     //have got permission
                    try{
                        startActivity(callIntent);  //call activity and make phone call
                    }
                    catch (android.content.ActivityNotFoundException ex){
                        Toast.makeText(getApplicationContext(),"yourActivity is not founded",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });



    }

    @Override
    protected void onStart()
    {
        super.onStart();

        final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Cart List");

        FirebaseRecyclerOptions<Cart> options =
                new FirebaseRecyclerOptions.Builder<Cart>()
                .setQuery(cartListRef.child("User View")
                .child(Prevalent.currentOnlineUser.getUsername())
                        .child("Products"), Cart.class)
                        .build();


        FirebaseRecyclerAdapter<Cart, CartViewHolder> adapter =
                new FirebaseRecyclerAdapter<Cart, CartViewHolder>(options)
                {
                    @SuppressLint("SetTextI18n")
                    @Override
                    protected void onBindViewHolder(@NonNull CartViewHolder holder, int position, @NonNull final Cart model)
                    {

                        holder.txtProductQuantity.setText("x " + model.getQuantity());
                        holder.txtProductRent.setText("Rent: " + model.getRent());
                        Picasso.get().load(model.getImage()).into(holder.cartImage);
                        holder.txtProductName.setText(model.getProductName());
                        if(model.isIfDiscounted())
                        {
                            holder.txtProductPrice.setText(model.getProductSalePrice());
                        }
                        else
                        {
                            holder.txtProductPrice.setText(model.getProductPrice());
                        }
//                        double oneTypeProductPrice = ((Integer.valueOf(model.getProductSalePrice()))) * (Integer.valueOf(model.getQuantity()));
//                        overTotalPrice = overTotalPrice + oneTypeProductPrice;

                        holder.itemView.setOnClickListener(new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View view)
                            {
                                CharSequence options[] = new CharSequence[]
                                        {
                                                "Edit",
                                                "Remove"
                                        };
                                AlertDialog.Builder builder = new AlertDialog.Builder(CartActivity.this);
                                 builder.setTitle("Cart Options");

                                builder.setItems(options, new DialogInterface.OnClickListener()
                                {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i)
                                    {
                                        if (i == 0)
                                        {
                                            Intent intent = new Intent(CartActivity.this, ProductDetailsActivity.class);
                                            intent.putExtra("productId", model.getProductId());
                                            startActivity(intent);
                                            setCart_heading();
                                        }
                                        if (i == 1)
                                        {
                                            cartListRef.child("User View")
                                                    .child(Prevalent.currentOnlineUser
                                                            .getUsername()).child("Products")
                                                    .child(model.getProductId())
                                                    .removeValue()
                                                    .addOnCompleteListener(new OnCompleteListener<Void>()
                                                    {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task)
                                                {
                                                    if (task.isSuccessful())
                                                    {
                                                        Toast.makeText(CartActivity.this, "Item removed from Cart", Toast.LENGTH_SHORT).show();
                                                        Intent intent = new Intent(CartActivity.this, CartActivity.class);
                                                        startActivity(intent);
                                                    }
                                                }
                                            });
                                            setCart_heading();
                                        }
                                    }
                                });
                                builder.show();
                            }
                        });
                    }

                    @NonNull
                    @Override
                    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
                    {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item_layout, parent, false);
                        CartViewHolder holder = new CartViewHolder(view);
                        return holder;
                    }
                };

        recycleView.setAdapter(adapter);
        adapter.startListening();
    }

    public void setCart_heading() {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Cart List").child("User View").child(Prevalent.currentOnlineUser.getUsername());
        reference.child("Products").addValueEventListener(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list=new ArrayList<>();
                for (DataSnapshot postshot : snapshot.getChildren()) {
                    Cart cart = postshot.getValue(Cart.class);
                    list.add(cart);
                }

                //Double totalAmount=0.0;
                for(int i=0;i<list.size();i++)
                {
                    Cart c=list.get(i);
                    if(c.isIfDiscounted())
                    {
                        totalAmount+=(Double.parseDouble(list.get(i).getProductSalePrice().substring(0,list.get(i).getProductSalePrice().length()-1))*Double.parseDouble(list.get(i).getQuantity()));
                    }
                    else
                    {
                        totalAmount+=(Double.parseDouble(list.get(i).getProductPrice().substring(0,list.get(i).getProductPrice().length()-1))*Double.parseDouble(list.get(i).getQuantity()));
                    }

                    totalRent += (Double.parseDouble(list.get(i).getRent().substring(0,list.get(i).getRent().length()-1))*Double.parseDouble(list.get(i).getQuantity()));


                }
                cart_heading.setText("Total Price : "+totalAmount+"$\n"+"Rent Price : "+totalRent+"$");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}