package com.example.finalapps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.finalapps.Model.Products;
import com.example.finalapps.ViewHolder.CategorySingleProductAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SingleCategoryItemActivity extends AppCompatActivity
{
    String type="";
    ArrayList<Products> productList;
    RecyclerView categorySingleRecyclerView;
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_category_item);
        reference= FirebaseDatabase.getInstance().getReference("Products");
        productList=new ArrayList<>();
        Bundle b=getIntent().getExtras();
        type=b.getString("category");
        categorySingleRecyclerView=findViewById(R.id.category_single_product);
        categorySingleRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        CategorySingleProductAdapter adapter=new CategorySingleProductAdapter(SingleCategoryItemActivity.this,productList,type);
        categorySingleRecyclerView.setAdapter(adapter);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot post:snapshot.getChildren())
                {
                    Products p=post.getValue(Products.class);
                    assert p != null;
                    if(p.getCategory().equals(type))
                    {
                        productList.add(p);
                    }
                }
                categorySingleRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                CategorySingleProductAdapter adapter=new CategorySingleProductAdapter(SingleCategoryItemActivity.this,productList,type);
                categorySingleRecyclerView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}