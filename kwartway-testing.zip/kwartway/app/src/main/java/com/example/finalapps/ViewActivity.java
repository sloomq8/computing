package com.example.finalapps;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.ar.core.Anchor;
import com.google.ar.core.Frame;
import com.google.ar.core.HitResult;
import com.google.ar.core.Trackable;
import com.google.ar.sceneform.AnchorNode;
import com.google.ar.sceneform.assets.RenderableSource;
import com.google.ar.sceneform.rendering.ModelRenderable;
import com.google.ar.sceneform.ux.ArFragment;
import com.google.ar.sceneform.ux.TransformableNode;

import java.util.List;

public class ViewActivity extends AppCompatActivity {

    private ArFragment arFragment;
    private FloatingActionButton floatingActionButton;
    private boolean isTracking = false;
    private boolean isHitting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        arFragment = (ArFragment) getSupportFragmentManager()
                .findFragmentById(R.id.sceneform_fragment);

        floatingActionButton = findViewById(R.id.floatingActionButton);

        arFragment.getArSceneView().getScene().addOnUpdateListener(frameTime -> {
            arFragment.onUpdate(frameTime);
            onUpdate();
        });

        final String productID = getIntent().getStringExtra("productId");
        String url = "https://raw.githubusercontent.com/engr-kishon/models/main/uploads_files_4400143_kreslo(1).glb";

        if (productID.equalsIgnoreCase("Mon, 20 Mar 202310:56:56 +0600")) {
            url = "https://sceneview.github.io/assets/models/Spoons.glb";
        }

        final Uri uri = Uri.parse(url);

        floatingActionButton.setOnClickListener(view -> {
            addObject(uri);
        });
    }

    private void showFab(boolean enabled) {
        if (enabled) {
            floatingActionButton.setEnabled(true);
            floatingActionButton.setVisibility(View.VISIBLE);
        } else {
            floatingActionButton.setEnabled(false);
            floatingActionButton.setVisibility(View.INVISIBLE);
        }
    }


    private void onUpdate() {
        updateTracking();

        if (isTracking) {
            final boolean hitTestChanged = updateHitTest();

            if (hitTestChanged) {
                showFab(isHitting);
            }
        }
    }

    private boolean updateHitTest() {
        final Frame frame = arFragment.getArSceneView().getArFrame();
        final Point point = getScreenCenter();
        final List<HitResult> hits;
        final boolean wasHitting = isHitting;
        isHitting = false;

        if (frame != null) {
            hits = frame.hitTest(point.x, point.y);
            for (HitResult hit : hits) {
                final Trackable trackable = hit.getTrackable();
                if (trackable instanceof com.google.ar.core.Plane
                        && ((com.google.ar.core.Plane) trackable)
                        .isPoseInPolygon(hit.getHitPose())) {
                    isHitting = true;
                    break;
                }
            }
        }

        return wasHitting != isHitting;
    }

    private Point getScreenCenter() {
        final View vw = findViewById(android.R.id.content);
        return new Point(vw.getWidth() / 2, vw.getHeight() / 2);
    }

    private boolean updateTracking() {
        final Frame frame = arFragment.getArSceneView().getArFrame();
        final boolean wasTracking = isTracking;
        isTracking = frame != null
                && frame.getCamera().getTrackingState() == com.google.ar.core.TrackingState.TRACKING;
        return wasTracking != isTracking;
    }

    private void addObject(Uri model) {
        final Frame frame = arFragment.getArSceneView().getArFrame();
        final Point point = getScreenCenter();
        final List<HitResult> hits;

        if (frame != null) {
            hits = frame.hitTest(point.x, point.y);
            for (HitResult hit : hits) {
                final Trackable trackable = hit.getTrackable();
                if (trackable instanceof com.google.ar.core.Plane
                        && ((com.google.ar.core.Plane) trackable)
                        .isPoseInPolygon(hit.getHitPose())) {
                    placeObject(arFragment, hit.createAnchor(), model);
                    break;
                }
            }
        }
    }

    private void placeObject(ArFragment arFragment, Anchor anchor, Uri model) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ModelRenderable.builder()
                    .setSource(arFragment.getContext(), new RenderableSource.Builder()
                            .setSource(this, model, RenderableSource.SourceType.GLB)
                            .setRecenterMode(RenderableSource.RecenterMode.ROOT)
                            .build())
                    .build()
                    .thenAccept(renderable -> addNodeToScene(arFragment, anchor, renderable))
                    .exceptionally(
                            throwable -> {
                                Toast.makeText(this, "Unable to load renderable", Toast.LENGTH_SHORT).show();
                                return null;
                            });
        }
    }

    private void addNodeToScene(ArFragment arFragment, Anchor anchor, ModelRenderable renderable) {
        final AnchorNode anchorNode = new AnchorNode(anchor);
        final TransformableNode transformableNode = new TransformableNode(arFragment.getTransformationSystem());
        transformableNode.setRenderable(renderable);
        transformableNode.setParent(anchorNode);
        arFragment.getArSceneView().getScene().addChild(anchorNode);
        transformableNode.select();
    }
}