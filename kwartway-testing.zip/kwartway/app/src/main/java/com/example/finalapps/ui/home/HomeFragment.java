package com.example.finalapps.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.slidingpanelayout.widget.SlidingPaneLayout;
import androidx.window.layout.WindowMetrics;
import androidx.window.layout.WindowMetricsCalculator;

import com.example.finalapps.Admin.AdminMaintainProductFragment;
import com.example.finalapps.Interface.ItemClickListener;
import com.example.finalapps.Model.Products;
import com.example.finalapps.Prevalent.Prevalent;
import com.example.finalapps.R;
import com.example.finalapps.LoginActivity;
import com.firebase.ui.common.ChangeEventType;
import com.firebase.ui.database.ChangeEventListener;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.apache.commons.collections4.ListUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;

    private DatabaseReference ProductsRef;

    public static SlidingPaneLayout slidingPaneLayout;

    private String type = "";

    private HomeViewModel homeViewModel;
      public  static  FragmentContainerView detail_container;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        homeViewModel = new ViewModelProvider(requireActivity()).get(HomeViewModel.class);

        ProductsRef = FirebaseDatabase.getInstance().getReference().child("Products");

        slidingPaneLayout = view.findViewById(R.id.slide_pane_layout);
        recyclerView = view.findViewById(R.id.recyclerViewPr);
        detail_container = view.findViewById(R.id.detail_container);

        type = LoginActivity.type;



        return view;
    }

    private ProductAdapter productAdapter;

    private boolean computeWindowSizeClasses() {
        WindowMetrics metrics = WindowMetricsCalculator.getOrCreate()
                .computeCurrentWindowMetrics(requireActivity());
        float widthDp = metrics.getBounds().width() /
                getResources().getDisplayMetrics().density;
        return widthDp >= 840f;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        FirebaseRecyclerOptions<Products> options = new FirebaseRecyclerOptions.Builder<Products>()
                .setLifecycleOwner(getViewLifecycleOwner())
                .setQuery(ProductsRef, Products.class)
                .build();

        options.getSnapshots().addChangeEventListener(new ChangeEventListener() {
            @Override
            public void onChildChanged(@NonNull ChangeEventType type, @NonNull DataSnapshot snapshot, int newIndex, int oldIndex) {

            }

            @Override
            public void onDataChanged() {
                List<Products> list = ListUtils.select(options.getSnapshots(), item -> item.getProductId() != null);
                homeViewModel.updateItems(list);
                if(isAdded())
                {
                    if (computeWindowSizeClasses() && list.size() > 0) {
                        homeViewModel.updateCurrent(list.get(0));
                    }
                }

            }

            @Override
            public void onError(@NonNull DatabaseError databaseError) {

            }
        });


        productAdapter = new ProductAdapter();
        recyclerView.setAdapter(productAdapter);
        recyclerView.setHasFixedSize(true);

        slidingPaneLayout.setLockMode(SlidingPaneLayout.LOCK_MODE_LOCKED);
        productAdapter.setItemClickListener(new ItemClickListener() {
            @Override
            public void onClick(Products product) {
                homeViewModel.updateCurrent(product);
                if (type.equals("Admin")) {
                    getChildFragmentManager().beginTransaction()
                            .replace(R.id.detail_container, new AdminMaintainProductFragment())
                            .commit();
                } else {
                    getChildFragmentManager().beginTransaction()
                            .replace(R.id.detail_container, new ProductDetailsFragment())
                            .commit();
                }
                slidingPaneLayout.openPane();
            }

            @Override
            public void fabClick(Products product) {
                try {
                    Log.d("fdkjfsdf", product.getName());
                    addToFavourite(product);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        homeViewModel.allItem.observe(getViewLifecycleOwner(), list -> {
            if (list == null) return;
            productAdapter.submitList(list);
            Log.d(this.getClass().getSimpleName(), "onDataChanged: " + list.toString());
        });

        requireActivity().getOnBackPressedDispatcher()
                .addCallback(getViewLifecycleOwner(), new SportsListOnBackPressedCallback(slidingPaneLayout));
    }

    private void addToFavourite(Products favProducts) {
        String saveCurrentDate, saveCurrentTime;

        Calendar calForDate;
        calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault());
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z", Locale.getDefault());
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Fav List1");

        final HashMap<String, Object> cartMap = new HashMap<>();
        cartMap.put("productId", favProducts.getProductId());
        cartMap.put("productName", favProducts.getName().toString());
        cartMap.put("productPrice", favProducts.getPrice().toString() + "$");
        cartMap.put("rent", favProducts.getRent().toString() + "$");
        cartMap.put("ProductSalePrice", favProducts.getSalePrice().toString() + "$");
        cartMap.put("ProductDescription", favProducts.getDescription().toString());
        cartMap.put("date", saveCurrentDate);
        cartMap.put("time", saveCurrentTime);
        cartMap.put("quantity", "1");
        cartMap.put("discount", "0");
        cartMap.put("ifDiscounted", false);
        cartMap.put("image", favProducts.getImage().toString());

        cartListRef.child("User View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                .child(favProducts.getProductId())
                .updateChildren(cartMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(requireContext(), "Item added to fav list", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }


    class SportsListOnBackPressedCallback extends OnBackPressedCallback implements SlidingPaneLayout.PanelSlideListener {
        private final SlidingPaneLayout sld;

        public SportsListOnBackPressedCallback(SlidingPaneLayout slidingPaneLayout) {
            super(slidingPaneLayout.isSlideable() && slidingPaneLayout.isOpen());
            this.sld = slidingPaneLayout;
            sld.addPanelSlideListener(this);
        }

        @Override
        public void handleOnBackPressed() {
            sld.closePane();
        }

        @Override
        public void onPanelSlide(@NonNull View panel, float slideOffset) {

        }

        @Override
        public void onPanelOpened(@NonNull View panel) {
            homeViewModel.setSearchVisibility(false);
            homeViewModel.setFabVisible(false);
            setEnabled(true);
        }

        @Override
        public void onPanelClosed(@NonNull View panel) {
            homeViewModel.setSearchVisibility(true);
            homeViewModel.setFabVisible(true);
            setEnabled(false);
        }
    }
}