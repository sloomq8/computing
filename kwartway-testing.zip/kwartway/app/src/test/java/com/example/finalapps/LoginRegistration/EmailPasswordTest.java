package com.example.finalapps.LoginRegistration;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


import com.example.finalapps.Model.EmailPassValidator;

import org.junit.Test;

public class EmailPasswordTest {
    @Test
    public void emailValidator_InvalidEmailNoTld_ReturnsTrue() {
        assertTrue(EmailPassValidator.isNotValidEmail("name@email"));
    }

    @Test
    public void emailValidator_InvalidEmailDoubleDot_ReturnsTrue() {
        assertTrue(EmailPassValidator.isNotValidEmail("name@email..com"));
    }

    @Test
    public void emailValidator_InvalidEmailNoUsername_ReturnsTrue() {
        assertTrue(EmailPassValidator.isNotValidEmail("@email.com"));
    }

    @Test
    public void emailValidator_EmptyString_ReturnsTrue() {
        assertTrue(EmailPassValidator.isEmpty(""));
    }

    @Test
    public void emailValidator_NullEmail_ReturnsTrue() {
        assertTrue(EmailPassValidator.isNotValidEmail(null));
    }

    @Test
    public void emailValidator_CorrectEmailSimple_ReturnsFalse() {
        assertFalse(EmailPassValidator.isNotValidEmail("name@email.com"));
    }

    @Test
    public void emailValidator_CorrectEmailSubDomain_ReturnsFalse() {
        assertFalse(EmailPassValidator.isNotValidEmail("name@email.co.uk"));
    }
}