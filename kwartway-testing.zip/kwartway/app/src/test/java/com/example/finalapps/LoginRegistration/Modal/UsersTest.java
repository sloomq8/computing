package com.example.finalapps.LoginRegistration.Modal;

import com.example.finalapps.Model.EmailPassValidator;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UsersTest {


    @Test
    public void isValidAndExist_EmptyEmail_Return0() {
        String email = "";
        String password = "testPassword";
        String userType = "Admin";
        TestUsers users = new TestUsers(email, password, userType);

        Assert.assertEquals(0, users.isValidAndExist());
    }

    @Test
    public void isValidAndExist_NotValidEmail_Return1() {
        String email = "names@om..f";
        String password = "testPassword";
        String userType = "Admin";
        TestUsers users = new TestUsers(email, password, userType);

        Assert.assertEquals(1, users.isValidAndExist());
    }

    @Test
    public void isValidAndExist_InvalidPassword_Return2() {
        String email = "name@email.com";
        String password = "";
        String userType = "Admin";
        TestUsers users = new TestUsers(email, password, userType);

        Assert.assertEquals(2, users.isValidAndExist());
    }

    @Test
    public void isValidAndExist_WithTrainer_Return3() {
        String email = "name@email.com";
        String password = "testPassword";
        String userType = "Admin";
        TestUsers users = new TestUsers(email, password, userType);

        Assert.assertEquals(3, users.isValidAndExist());
    }
    @Test
    public void isValidAndExist_WithClients_Return4() {
        String email = "name@email.com";
        String password = "testPassword";
        String userType = "user";
        TestUsers users = new TestUsers(email, password, userType);

        Assert.assertEquals(4, users.isValidAndExist());
    }
    @Test
    public void isValidAndExist_WithUnknownType_ReturnError() {
        String email = "name@email.com";
        String password = "testPassword";
        String userType = "";
        TestUsers users = new TestUsers(email, password, userType);

        Assert.assertEquals(-1, users.isValidAndExist());
    }
}

class TestUsers {
    private final String email;
    private final String password;
    private final String userType;

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public TestUsers(String email, String password, String userType) {
        this.email = email;
        this.password = password;
        this.userType = userType;
    }

    public int isValidAndExist() {
        if (EmailPassValidator.isEmpty(getEmail()))
            return 0;
        else if (EmailPassValidator.isNotValidEmail(getEmail()))
            return 1;
        else if (EmailPassValidator.isNotValidPassword(getPassword()))
            return 2;
        else {
            if (userType.equals("Admin")) {
                return 3;
            } else if((userType.equals("user"))) {
                return 4;
            }
            return -1;
        }
    }
}