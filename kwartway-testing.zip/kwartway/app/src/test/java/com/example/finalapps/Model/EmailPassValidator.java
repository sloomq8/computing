package com.example.finalapps.Model;

import java.util.regex.Pattern;

public class EmailPassValidator {
    public static final Pattern EMAIL_PATTERN = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
    );

    /**
     * Validates if the given input is a valid email address.
     *
     * @param email The email to validate.
     * @return {@code true} if the input is a valid email. {@code false} otherwise.
     */
    public static boolean isNotValidEmail(CharSequence email) {
        if (email == null) {
            return true;
        }
        return !EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean isNotValidPassword(String password) {
        return password.length() <= 0;
    }

    public static boolean isEmpty(String email) {
        return email.trim().isEmpty();
    }
}
