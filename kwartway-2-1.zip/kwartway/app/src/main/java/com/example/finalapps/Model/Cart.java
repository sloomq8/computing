package com.example.finalapps.Model;

public class Cart
{
    private String productId;
    private String image;
    private String productName;
    private String productPrice;
    private String rent;
    private String ProductSalePrice;
    private String quantity;
    private String discount;
    boolean ifDiscounted;

    public Cart(){}


    public Cart(String productId, String image, String productName, String productPrice,String rent, String productSalePrice, String quantity, String discount, boolean ifDiscounted) {
        this.productId = productId;
        this.image = image;
        this.productName = productName;
        this.productPrice = productPrice;
        this.rent = rent;
        this.ProductSalePrice = productSalePrice;
        this.quantity = quantity;
        this.discount = discount;
        this.ifDiscounted = ifDiscounted;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getRent() {
        return rent;
    }

    public void setRent(String rent) {
        this.rent = rent;
    }

    public String getProductSalePrice() {
        return ProductSalePrice;
    }

    public void setProductSalePrice(String productSalePrice) {
        ProductSalePrice = productSalePrice;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public boolean isIfDiscounted() {
        return ifDiscounted;
    }

    public void setIfDiscounted(boolean ifDiscounted) {
        this.ifDiscounted = ifDiscounted;
    }
}
