package com.example.finalapps.Model;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalapps.R;

import java.util.List;

public class CateoryAdapter extends RecyclerView.Adapter<CateoryAdapter.ViewHolder>
{
    private List<Category> categoryList;

    public CateoryAdapter(List<Category> categoryList) {
        this.categoryList = categoryList;
    }

    @NonNull
    @Override
    public CateoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CateoryAdapter.ViewHolder holder, int position) {

        String icon = categoryList.get(position).getCategoryIconLink();
        String name = categoryList.get(position).getCategoryName();
        holder.setCategoryName(name);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

//        private ImageView CategoryIcon;
        private TextView CategoryName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

//            CategoryIcon = itemView.findViewById(R.id.category_icon);
            CategoryName = itemView.findViewById(R.id.category_name);
        }

        private void setCategoryIcon() {
//        todo: set Category
        }

        private void setCategoryName(String name) {
            CategoryName.setText(name);
        }
    }
}
