package com.example.finalapps.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.finalapps.HomeActivity;
import com.example.finalapps.MainActivity;
import com.example.finalapps.R;

public class adminCategoryActivity extends AppCompatActivity
{


    private Button ManageProductsButton, AdminLogoutButton,addProductButton;
    private Button deliveryOrder, allDeliveryStatus;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_category);




        ManageProductsButton = (Button) findViewById(R.id.manage_products);
        addProductButton = (Button) findViewById(R.id.add_new_product);
        AdminLogoutButton = (Button) findViewById(R.id.admin_logout);
        deliveryOrder = findViewById(R.id.deliveryOrder);
        allDeliveryStatus = findViewById(R.id.allDeliveryStatus);


        addProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(adminCategoryActivity.this, adminActivity.class);
                startActivity(intent);
            }
        });



        ManageProductsButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(adminCategoryActivity.this, HomeActivity.class);
                intent.putExtra("Admin", "Admin");
                startActivity(intent);
            }
        });



        deliveryOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(adminCategoryActivity.this, DeliveryActivity.class);
                startActivity(intent);
            }
        });


        AdminLogoutButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                adminLogout();
            }
        });


    }

    private void adminLogout()
    {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}