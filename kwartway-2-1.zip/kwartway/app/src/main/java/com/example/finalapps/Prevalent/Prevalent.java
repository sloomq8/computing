package com.example.finalapps.Prevalent;

import com.example.finalapps.Model.Users;

public class Prevalent
{
   // public static Users currentOnlineUser;
    public static Users currentOnlineUser;

    public static final String userUsernameKey = "userUsernameKey";
    public static final String userPasswordKey = "userPasswordKey";
}
