package com.example.finalapps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.esotericsoftware.kryo.NotNull;
import com.example.finalapps.Model.Cart;
import com.example.finalapps.Model.OrderDetails;
import com.example.finalapps.Model.OrderItem;
import com.example.finalapps.Model.PaymentDetails;
import com.example.finalapps.Prevalent.Prevalent;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.paypal.checkout.approve.Approval;
import com.paypal.checkout.approve.OnApprove;
import com.paypal.checkout.createorder.CreateOrder;
import com.paypal.checkout.createorder.CreateOrderActions;
import com.paypal.checkout.createorder.CurrencyCode;
import com.paypal.checkout.createorder.OrderIntent;
import com.paypal.checkout.createorder.UserAction;
import com.paypal.checkout.order.Amount;
import com.paypal.checkout.order.AppContext;
import com.paypal.checkout.order.CaptureOrderResult;
import com.paypal.checkout.order.OnCaptureComplete;
import com.paypal.checkout.order.Order;
import com.paypal.checkout.order.PurchaseUnit;
import com.paypal.checkout.paymentbutton.PaymentButtonContainer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import java.util.Properties;

public class ConfirmFinalOrderActivity extends AppCompatActivity {
    private EditText editTextEmail, editTextPhone, editTextPaymentDescription, etAddress;
    private Button showAllOrderBtn,btn_cash_delivery;
    private PaymentButtonContainer confirmOrderBtn;
    private Double totalAmount = 0.0;
    //    private Double discountedAmount=0.0;
    private ProgressDialog loadingBar;
    TextView totalAmountView;
    ArrayList<Cart> cartList;
    DatabaseReference reference, cartListRef;
    public static boolean isFav = false;
    String Id;
    String productsCodes = "";
    DatabaseReference orderDetailsReference;

    RadioGroup rg1;
    RadioButton rb1;

    String paymentMethodName;
    public static boolean isBuy = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_final_order);

//        totalAmount = getIntent().getStringExtra("Total Price");
//
//        Toast.makeText(this, "Total Price =  $ " + totalAmount, Toast.LENGTH_SHORT).show();

//        discountedAmount = getIntent().getStringExtra("discountedAmount");
        loadingBar = new ProgressDialog(this);

        rg1 = (RadioGroup) findViewById(R.id.radioGroup);

        loadingBar = new ProgressDialog(this);
        totalAmountView = findViewById(R.id.confirm_final_order_total_no);
        confirmOrderBtn = findViewById(R.id.confirm_final_order_btn);
        btn_cash_delivery = findViewById(R.id.btn_cash_delivery);
        showAllOrderBtn = (Button) findViewById(R.id.previous_order_btn);
        editTextPaymentDescription = (EditText) findViewById(R.id.payment_description);
        editTextEmail = (EditText) findViewById(R.id.shipment_email);
        editTextPhone = (EditText) findViewById(R.id.shipment_phone);
        etAddress = (EditText) findViewById(R.id.etAddress);

        cartList = new ArrayList<>();
        Bundle b = getIntent().getExtras();
        totalAmount = b.getDouble("totalAmount");
        totalAmountView.setText("$" + totalAmount.toString() + "");

//        Bundle b1=getIntent().getExtras();
//        discountedAmount=b1.getDouble("discountedAmount");
//        discountedAmountView.setText("$"+discountedAmount.toString()+"");

        Log.d("fdlkfj", Boolean.toString(isFav));

        if (isFav) {
            cartListRef = FirebaseDatabase.getInstance().getReference("Fav List1").child("User View").child(Prevalent.currentOnlineUser.getUsername()).child("Products");
            Log.d("kjkdjfk", "Fav");
        } else {
            cartListRef = FirebaseDatabase.getInstance().getReference("Cart List").child("User View").child(Prevalent.currentOnlineUser.getUsername()).child("Products");
            Log.d("kjkdjfk", "Cart");
        }

        cartListRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cartList.clear();
                for (DataSnapshot postshot : snapshot.getChildren()) {
                    Cart cart = postshot.getValue(Cart.class);
                    Log.d("kjkdjfk", cart.getProductName());
                    productsCodes += cart.getProductId();
                    cartList.add(cart);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        btn_cash_delivery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateField("Cash");
            }
        });

        confirmOrderBtn.setup(
                new CreateOrder() {
                    @Override
                    public void create(@NonNull CreateOrderActions createOrderActions) {
                        ArrayList<PurchaseUnit> purchaseUnits = new ArrayList<>();
                        purchaseUnits.add(
                                new PurchaseUnit.Builder()
                                        .amount(
                                                new Amount.Builder()
                                                        .currencyCode(CurrencyCode.USD)
                                                        .value(String.valueOf(totalAmount))
                                                        .build()
                                        )
                                        .build()
                        );
                        Order order = new Order(
                                OrderIntent.CAPTURE,
                                new AppContext.Builder()
                                        .userAction(UserAction.PAY_NOW)
                                        .build(),
                                purchaseUnits
                        );
                        createOrderActions.create(order, (CreateOrderActions.OnOrderCreated) null);
                    }
                },
                new OnApprove() {
                    @Override
                    public void onApprove(@NonNull Approval approval) {
                        approval.getOrderActions().capture(new OnCaptureComplete() {
                            @Override
                            public void onCaptureComplete(@NonNull CaptureOrderResult result) {
                                validateField("PayPal");
                            }
                        });
                    }
                }
        );


        showAllOrderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ConfirmFinalOrderActivity.this, AllOrders.class));
            }
        });

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    private void validateField(String paymentMethodName) {
        //boolean missing=true;
//        int selected=rg1.getCheckedRadioButtonId();
//        rb1=(RadioButton)findViewById(selected);
//        if(rb1.getText().toString() == null)
//        {
//            Toast.makeText(this, "Please select payment method", Toast.LENGTH_SHORT).show();
//        }
//        else if(editTextPaymentDescription.getText().toString().length()==0)
//        {
//            Toast.makeText(this, "Please Enter Payment Details", Toast.LENGTH_SHORT).show();
//        }
//        else
        if (editTextEmail.getText().toString().length() == 0) {
            Toast.makeText(this, "Please Enter Your email", Toast.LENGTH_SHORT).show();
        } else if (editTextPhone.getText().toString().length() == 0) {
            Toast.makeText(this, "Please Enter Phone No", Toast.LENGTH_SHORT).show();
        } else if (etAddress.getText().toString().length() == 0) {
            Toast.makeText(this, "Please Enter your address", Toast.LENGTH_SHORT).show();
        }
        else {
            paymentMethodName = paymentMethodName;

            if (isFav) {
                checkOrder2();
            } else {
                checkOrder();
            }

        }
    }

    private void checkOrder() {
        final String saveCurrentDate, saveCurrentTime;

        Calendar calForDate;
        calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy");
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z");
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final DatabaseReference orderReference = FirebaseDatabase.getInstance().getReference()
                .child("Orders");
        orderDetailsReference = FirebaseDatabase.getInstance().getReference()
                .child("OrdersDetails");
        loadingBar.setTitle("Order is processing");
        loadingBar.setMessage("You will be confirmation email");
        loadingBar.setCanceledOnTouchOutside(false);
        loadingBar.show();


        // ShipmentDetail sd=new ShipmentDetail(editTextName.getText().toString(),editTextEmail.getText().toString(),editTextPhone.getText().toString(),editTextAddress.getText().toString(),editTextCity.getText().toString(),editTextCountry.getText().toString(),editTextZipCode.getText().toString(),editTextNotes.getText().toString());
        final PaymentDetails paymentDetails = new PaymentDetails(paymentMethodName, editTextPaymentDescription.getText().toString(), editTextPhone.getText().toString(), editTextEmail.getText().toString());
        // Order order=new Order(currentTime.toString(),Prevalent.currentOnlineUser.getUsername(),new Date(),cartList,sd,totalAmount);


        int code = new Random().nextInt(100000) + new Random().nextInt(100000);
        Id = String.valueOf(code);
        OrderItem orderItem = new OrderItem(Id, saveCurrentDate, Prevalent.currentOnlineUser.getUsername(), saveCurrentTime, String.valueOf(totalAmount), Constants.ORDERNOTDEVILVERD, paymentDetails,etAddress.getText().toString());
        orderReference.child(Id).setValue(orderItem).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    FirebaseDatabase.getInstance().getReference().child("Cart List").child("User View")
                            .child(Prevalent.currentOnlineUser.getUsername())
                            .removeValue()
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {

                                        OrderDetails orderDetails = new OrderDetails(Id, productsCodes);
                                        Log.d("kjkdjfk", productsCodes);
                                        //  Log.d("kjkdjfk","inside"+cartList.get(0).getProductName());
                                        orderDetailsReference.child(Id).setValue(orderDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    //sendConfirmationEmail(editTextEmail.getText().toString().trim(),Id,String.valueOf(totalAmount));

                                                    editTextPaymentDescription.setText("");
                                                    editTextPhone.setText("");
                                                    editTextEmail.setText("");
                                                    loadingBar.dismiss();
                                                    Toast.makeText(ConfirmFinalOrderActivity.this, "Succeesfully ordered", Toast.LENGTH_SHORT).show();


                                                }
                                            }
                                        });

                                    }
                                }
                            });
                }
            }
        });
    }

    private void checkOrder2() {
        final String saveCurrentDate, saveCurrentTime;

        Calendar calForDate;
        calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy");
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z");
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final DatabaseReference orderReference = FirebaseDatabase.getInstance().getReference()
                .child("Orders");

        // ShipmentDetail sd=new ShipmentDetail(editTextName.getText().toString(),editTextEmail.getText().toString(),editTextPhone.getText().toString(),editTextAddress.getText().toString(),editTextCity.getText().toString(),editTextCountry.getText().toString(),editTextZipCode.getText().toString(),editTextNotes.getText().toString());
        //  Order order=new Order(currentTime.toString(),Prevalent.currentOnlineUser.getUsername(),new Date(),cartList,sd,totalAmount);
        // HashMap<String, Object> OrderMap = new HashMap<>();
        //OrderMap.put(currentTime.toString(),o);
        PaymentDetails paymentDetails = new PaymentDetails(paymentMethodName, editTextPaymentDescription.getText().toString(), editTextPhone.getText().toString(), editTextEmail.getText().toString());
        OrderItem orderItem = new OrderItem(Id, saveCurrentDate, Prevalent.currentOnlineUser.getUsername(), saveCurrentTime, String.valueOf(totalAmount), Constants.ORDERNOTDEVILVERD, paymentDetails,etAddress.getText().toString());

        int code = new Random().nextInt(100000) + new Random().nextInt(100000);
        Id = String.valueOf(code);
        orderReference.child(Id).setValue(orderItem).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    FirebaseDatabase.getInstance().getReference().child("Fav List1").child("User View")
                            .child(Prevalent.currentOnlineUser.getUsername())
                            .removeValue()
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        OrderDetails orderDetails = new OrderDetails(Id, productsCodes);
                                        orderDetailsReference.child(Id).setValue(orderDetails).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    // sendConfirmationEmail(editTextEmail.getText().toString(),Id,String.valueOf(totalAmount));

                                                    editTextPaymentDescription.setText("");
                                                    editTextPhone.setText("");
                                                    editTextEmail.setText("");
                                                    etAddress.setText("");
                                                    loadingBar.dismiss();
                                                    Toast.makeText(ConfirmFinalOrderActivity.this, "Succeesfully ordered", Toast.LENGTH_SHORT).show();

                                                }
                                            }
                                        });
                                    }
                                }
                            });
                }
            }
        });
    }

    public void sendConfirmationEmail(String clinetEmail, String orderCode, String amount) {
        final String username = "alon.beck200@gmail.com";
        final String password = "RRrr1234";
        String messageToSend = "Congratulations you have suffessfully ordered\n" + "Order Code : " + orderCode + "\n amount : " + amount;
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(clinetEmail));
            message.setSubject("Order confirmation from Shoes Shop");
            message.setText(messageToSend);
            Transport.send(message);
            Toast.makeText(ConfirmFinalOrderActivity.this, "Succeed Check your email" + clinetEmail, Toast.LENGTH_SHORT).show();
            editTextPaymentDescription.setText("");
            editTextPhone.setText("");
            editTextEmail.setText("");
            loadingBar.dismiss();

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }

}