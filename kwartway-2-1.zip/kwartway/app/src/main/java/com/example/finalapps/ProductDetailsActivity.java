package com.example.finalapps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.finalapps.Model.Products;
import com.example.finalapps.Prevalent.Prevalent;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import co.sspp.library.SweetAlertDialog;

public class ProductDetailsActivity extends AppCompatActivity {

    private ImageView ProductDetailImageView;
    private Button addToCartButton, addToFavButton;
    private ElegantNumberButton numberButton;
    private TextView ProductName, ProductPrice, ProductRent, ProductSalePrice, ProductDescription;
    private String productID = "", imageString = "";
    boolean ifDiscounted;
    int ProductQuantity = 0;

    private View view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        productID = getIntent().getStringExtra("productId");

        addToCartButton = (Button) findViewById(R.id.add_to_cart_btn);
        addToFavButton = (Button) findViewById(R.id.add_to_fav_btn);
        ProductDetailImageView = (ImageView) findViewById(R.id.product_image_details);
        numberButton = (ElegantNumberButton) findViewById(R.id.number_btn);
        ProductName = (TextView) findViewById(R.id.product_name_details);
        ProductSalePrice = (TextView) findViewById(R.id.product_sale_price_details);
        ProductPrice = (TextView) findViewById(R.id.product_price_details);
        ProductRent = (TextView) findViewById(R.id.product_rent);
        ProductDescription = (TextView) findViewById(R.id.product_description_details);
        view = findViewById(R.id.root);
        getProductDetails();

        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int qty = Integer.valueOf(numberButton.getNumber());
                if (ProductQuantity < qty) {
                    Toast.makeText(ProductDetailsActivity.this, "product is not available", Toast.LENGTH_SHORT).show();
                } else {
                    ProductQuantity -= qty;
                    addToCart();
                }

            }
        });
        addToFavButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addToFavourite();
            }
        });

        findViewById(R.id.view_product_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductDetailsActivity.this,
                        ViewActivity.class);
                intent.putExtra("productId", productID);
                startActivity(intent);
            }
        });

    }

    private void addToCart() {
        String saveCurrentDate, saveCurrentTime;

        Calendar calForDate;
        calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy");
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z");
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Cart List");

        final HashMap<String, Object> cartMap = new HashMap<>();
        cartMap.put("productId", productID);
        cartMap.put("productName", ProductName.getText().toString());
        cartMap.put("productPrice", ProductPrice.getText().toString());
        cartMap.put("rent", ProductRent.getText().toString());
        cartMap.put("ProductSalePrice", ProductSalePrice.getText().toString());
        cartMap.put("ProductDescription", ProductDescription.getText().toString());
        cartMap.put("date", saveCurrentDate);
        cartMap.put("time", saveCurrentTime);
        cartMap.put("quantity", numberButton.getNumber());
        cartMap.put("discount", "");
        cartMap.put("ifDiscounted", ifDiscounted);
        cartMap.put("image", imageString);

        cartListRef.child("User View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                .child(productID)
                .updateChildren(cartMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            cartListRef.child("Admin View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                                    .child(productID)
                                    .updateChildren(cartMap)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                updateProduct();

                                            }
                                        }
                                    });
                        }
                    }
                });

    }

    private void updateProduct() {
        DatabaseReference ref;
        ref = FirebaseDatabase.getInstance().getReference().child("Products");

        HashMap<String, Object> productMap = new HashMap<>();
        productMap.put("quantity", String.valueOf(ProductQuantity));

        ref.child(productID).updateChildren(productMap);

        Toast.makeText(ProductDetailsActivity.this, "Item added to cart list", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(ProductDetailsActivity.this, HomeActivity.class);
        startActivity(intent);
    }


    private void getProductDetails() {
        DatabaseReference productRef = FirebaseDatabase.getInstance().getReference().child("Products");

        productRef.child(productID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Products products = snapshot.getValue(Products.class);
                    imageString = products.getImage();
                    ProductName.setText(products.getName());
                    ProductPrice.setText(products.getPrice() + "$");
                    ProductRent.setText(products.getRent() + "$");
                    ProductSalePrice.setText(products.getSalePrice() + "$");
                    ProductDescription.setText(products.getDescription());
                    ProductQuantity = Integer.valueOf(products.getQuantity());
                    ifDiscounted = products.isIfDiscounted();
                    if (!ifDiscounted) {
                        ProductSalePrice.setVisibility(View.VISIBLE);
                    }
                    Picasso.get().load(products.getImage()).into(ProductDetailImageView);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void addToFavourite() {
        String saveCurrentDate, saveCurrentTime;

        Calendar calForDate;
        calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy");
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z");
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Fav List1");

        final HashMap<String, Object> cartMap = new HashMap<>();
        cartMap.put("productId", productID);
        cartMap.put("productName", ProductName.getText().toString());
        cartMap.put("productPrice", ProductPrice.getText().toString());
        cartMap.put("rent", ProductRent.getText().toString());
        cartMap.put("ProductSalePrice", ProductSalePrice.getText().toString());
        cartMap.put("ProductDescription", ProductDescription.getText().toString());
        cartMap.put("date", saveCurrentDate);
        cartMap.put("time", saveCurrentTime);
        cartMap.put("quantity", numberButton.getNumber());
        cartMap.put("discount", "");
        cartMap.put("ifDiscounted", ifDiscounted);
        cartMap.put("image", imageString);

        cartListRef.child("User View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                .child(productID)
                .updateChildren(cartMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            cartListRef.child("Admin View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                                    .child(productID)
                                    .updateChildren(cartMap)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {

                                                Snackbar.make(view, "Item added to favourite ", Snackbar.LENGTH_SHORT).show();

                                              /*  Intent intent = new Intent(HomeActivity.this, CartActivity.class);
                                                startActivity(intent);*/

                                            }
                                        }
                                    });
                        }
                    }
                });

    }
}