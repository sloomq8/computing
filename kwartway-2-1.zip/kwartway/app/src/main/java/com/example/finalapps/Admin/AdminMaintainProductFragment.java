package com.example.finalapps.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.finalapps.R;
import com.example.finalapps.ui.home.HomeViewModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class AdminMaintainProductFragment extends Fragment {

    private Button ApplyChangesButton, DeleteProductButton;
    private ImageView ImageView;
    private EditText Code, Name, Price, Rent, Quantity, Description;
    private String productID = "";

    private DatabaseReference productsRef;
    private HomeViewModel homeViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_admin_maintain_products, container, false);

        homeViewModel = new ViewModelProvider(requireActivity()).get(HomeViewModel.class);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        ApplyChangesButton = view.findViewById(R.id.admin_apply_changes_btn);
        DeleteProductButton = view.findViewById(R.id.admin_delete_product_btn);
        ImageView = view.findViewById(R.id.product_image_maintain);
        Code = view.findViewById(R.id.product_code_maintain);
        Name = view.findViewById(R.id.product_name_maintain);
        Price = view.findViewById(R.id.product_price_maintain);
        Rent = view.findViewById(R.id.product_rent_maintain);
        Quantity = view.findViewById(R.id.product_quantity_maintain);
        Description = view.findViewById(R.id.product_description_maintain);

        homeViewModel.currentItem.observe(getViewLifecycleOwner(), item -> {
            productID = item.getProductId();
            productsRef = FirebaseDatabase.getInstance().getReference().child("Products").child(productID);

            Name.setText(item.getName());
            Price.setText(item.getPrice());
            Rent.setText(item.getRent());
            Code.setText(item.getCode());
            Quantity.setText(item.getQuantity());
            Description.setText(item.getDescription());
            Picasso.get().load(item.getImage()).into(ImageView);

        });

        ApplyChangesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                applyChanges();
            }
        });

        DeleteProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteProduct();
            }
        });
    }

    private void deleteProduct() {
        productsRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(requireContext(), "Product deleted Successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void applyChanges() {
        String appliedName = Name.getText().toString();
        String appliedPrice = Price.getText().toString();
        String appliedRent = Rent.getText().toString();
        String appliedCode = Code.getText().toString();
        String appliedQuantity = Quantity.getText().toString();
        String appliedDescription = Description.getText().toString();

        if (appliedName.equals("")) {
            Toast.makeText(requireContext(), "Please, Enter Name", Toast.LENGTH_SHORT).show();
        } else if (appliedPrice.equals("")) {
            Toast.makeText(requireContext(), "Please, Enter Price", Toast.LENGTH_SHORT).show();
        } else if (appliedRent.equals("")) {
            Toast.makeText(requireContext(), "Please, Enter Rent", Toast.LENGTH_SHORT).show();
        } else if (appliedCode.equals("")) {
            Toast.makeText(requireContext(), "Please, Enter Product code", Toast.LENGTH_SHORT).show();
        } else if (appliedQuantity.equals("")) {
            Toast.makeText(requireContext(), "Please, Enter Product quantity", Toast.LENGTH_SHORT).show();
        } else if (appliedDescription.equals("")) {
            Toast.makeText(requireContext(), "Please, Enter Description", Toast.LENGTH_SHORT).show();
        } else {
            HashMap<String, Object> productMap = new HashMap<>();
            productMap.put("productId", productID);
            productMap.put("description", appliedDescription);
            productMap.put("price", appliedPrice);
            productMap.put("rent", appliedRent);
            productMap.put("salePrice", appliedPrice);
            productMap.put("name", appliedName);
            productMap.put("quantity", appliedQuantity);
            productMap.put("code", appliedCode);

            productsRef.updateChildren(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(requireContext(), "Changes applied Successfully", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(requireContext(), adminCategoryActivity.class);
                        startActivity(intent);
                        requireActivity().finish();
                    }
                }
            });
        }

    }
}