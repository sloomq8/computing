package com.example.finalapps.chat;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.applozic.mobicomkit.api.account.register.RegistrationResponse;
import com.example.finalapps.R;

import io.kommunicate.KmConversationBuilder;
import io.kommunicate.KmConversationHelper;
import io.kommunicate.Kommunicate;
import io.kommunicate.callbacks.KMLoginHandler;
import io.kommunicate.callbacks.KmCallback;

public class ChatActivity extends AppCompatActivity {


    public static final String TAG = "ChatActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        Kommunicate.init(this, "38173a6e141bc762358c6a1856142c0a8");

        Kommunicate.loginAsVisitor(this, new KMLoginHandler() {
            @Override
            public void onSuccess(RegistrationResponse registrationResponse, Context context) {
                loadChat();
            }

            @Override
            public void onFailure(RegistrationResponse registrationResponse, Exception exception) {
                Log.d(TAG, "onFailure: " + exception.getMessage());
            }
        });
    }

    private void loadChat() {

        new KmConversationBuilder(this)
                .setSingleConversation(false)
                .createConversation(new KmCallback() {
                    @Override
                    public void onSuccess(Object message) {
                        String conversationId = message.toString();
                        openConversation(Integer.parseInt(conversationId));
                    }

                    @Override
                    public void onFailure(Object error) {
                        Log.d("ConversationTest", "Error : " + error);
                    }
                });
    }

    private void openConversation(int conversationId) {

        try {
            KmConversationHelper.openConversation(this,
                    true,
                    conversationId,
                    new KmCallback() {
                        @Override
                        public void onSuccess(Object message) {

                        }

                        @Override
                        public void onFailure(Object error) {

                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


}

