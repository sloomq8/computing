package com.example.finalapps.ui.home;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.window.layout.WindowMetrics;
import androidx.window.layout.WindowMetricsCalculator;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.finalapps.HomeActivity;
import com.example.finalapps.Model.Cart;
import com.example.finalapps.Prevalent.Prevalent;
import com.example.finalapps.ProductDetailsActivity;
import com.example.finalapps.R;
import com.example.finalapps.ViewActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

import co.sspp.library.SweetAlertDialog;

public class ProductDetailsFragment extends Fragment {

    private ImageView ProductDetailImageView;
    private Button addToCartButton, addToFavButton;
    private ElegantNumberButton numberButton;
    private TextView ProductName, ProductPrice, ProductRent, ProductSalePrice, ProductDescription;
    private String productID = "", imageString = "";
    boolean ifDiscounted;
    int ProductQuantity = 0;

    private HomeViewModel homeViewModel;
    Button button;
    LinearLayout layout;
    RelativeLayout root;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        homeViewModel = new ViewModelProvider(requireActivity()).get(HomeViewModel.class);
        return inflater.inflate(R.layout.activity_product_details, container, false);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        productID = getIntent().getStringExtra("productId");
        productID = "0";

        addToCartButton = (Button) view.findViewById(R.id.add_to_cart_btn);
        addToFavButton = (Button) view.findViewById(R.id.add_to_fav_btn);
        ProductDetailImageView = (ImageView) view.findViewById(R.id.product_image_details);
        numberButton = (ElegantNumberButton) view.findViewById(R.id.number_btn);
        ProductName = (TextView) view.findViewById(R.id.product_name_details);
        ProductSalePrice = (TextView) view.findViewById(R.id.product_sale_price_details);
        ProductPrice = (TextView) view.findViewById(R.id.product_price_details);
        ProductRent = (TextView) view.findViewById(R.id.product_rent);
        ProductDescription = (TextView) view.findViewById(R.id.product_description_details);
        button = view.findViewById(R.id.button);
        layout = view.findViewById(R.id.layout);
        root = view.findViewById(R.id.root);

        homeViewModel.currentItem.observe(getViewLifecycleOwner(), products -> {
            if (products == null) return;
            productID = products.getProductId();
            imageString = products.getImage();
            ProductName.setText(products.getName());
            ProductPrice.setText(products.getPrice() + "$");
            ProductRent.setText(products.getRent() + "$");
            ProductSalePrice.setText(products.getSalePrice() + "$");
            ProductDescription.setText(products.getDescription());
            ProductQuantity = Integer.parseInt(products.getQuantity());
            ifDiscounted = products.isIfDiscounted();
            if (!ifDiscounted) {
                ProductSalePrice.setVisibility(View.VISIBLE);
            }
            Picasso.get().load(products.getImage()).into(ProductDetailImageView);
        });

        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new SweetAlertDialog(getContext(), SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Are you sure?")
                        .setContentText("You want to add this product to cart!")
                        .setConfirmText("Yes")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {

                                sDialog.dismissWithAnimation();
                                int qty = Integer.parseInt(numberButton.getNumber());
                                if (ProductQuantity < qty) {
                                    Toast.makeText(requireContext(), "Product is not available", Toast.LENGTH_SHORT).show();
                                } else {


                                    ProductQuantity -= qty;
                                    addToCart();
                                }
                            }
                        })
                        .setCancelText("No")
                        .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.cancel();
                            }
                        })
                        .show();


            }
        });
        addToFavButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                homeViewModel.setStateSnackbar(true);
              /*  Snackbar snackbar = Snackbar.make(HomeActivity.drawer_layout, "Do you want to check out?", 3000);
                snackbar.setAction("Yes",c->{
                    snackbar.dismiss();
                    getChildFragmentManager().beginTransaction()
                            .replace(R.id.detail_container, new FavouriteFragment())
                            .commit();

                });
                snackbar.show();*/
                addToFavourite();
            }
        });

        view.findViewById(R.id.view_product_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(requireContext(),
                        ViewActivity.class);
                intent.putExtra("productId", productID);
                startActivity(intent);
            }
        });

    }

    private void addToCart() {
        String saveCurrentDate, saveCurrentTime;

        Calendar calForDate;
        calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault());
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z", Locale.getDefault());
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Cart List");

        final HashMap<String, Object> cartMap = new HashMap<>();
        cartMap.put("productId", productID);
        cartMap.put("productName", ProductName.getText().toString());
        cartMap.put("productPrice", ProductPrice.getText().toString());
        cartMap.put("rent", ProductRent.getText().toString());
        cartMap.put("ProductSalePrice", ProductSalePrice.getText().toString());
        cartMap.put("ProductDescription", ProductDescription.getText().toString());
        cartMap.put("date", saveCurrentDate);
        cartMap.put("time", saveCurrentTime);
        cartMap.put("quantity", numberButton.getNumber());
        cartMap.put("discount", "");
        cartMap.put("ifDiscounted", ifDiscounted);
        cartMap.put("image", imageString);

        cartListRef.child("User View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                .child(productID)
                .updateChildren(cartMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            cartListRef.child("Admin View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                                    .child(productID)
                                    .updateChildren(cartMap)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                updateProduct();
                                                Snackbar snackbar = Snackbar.make(HomeActivity.drawer_layout, "Product added to cart.", Snackbar.LENGTH_SHORT);
                                                snackbar.setAction("View", c -> {
                                                    snackbar.dismiss();
                                                    requireActivity().getSupportFragmentManager().beginTransaction()
                                                            .replace(R.id.parentContainer, new CartFragment())
                                                            .commit();

                                                });
                                                snackbar.show();
                                            }
                                        }
                                    });
                        }
                    }
                });

    }

    private void updateProduct() {
        DatabaseReference ref;
        ref = FirebaseDatabase.getInstance().getReference().child("Products");

        HashMap<String, Object> productMap = new HashMap<>();
        productMap.put("quantity", String.valueOf(ProductQuantity));

        ref.child(productID).updateChildren(productMap);

//        if (!computeWindowSizeClasses()) {
//            requireActivity().onBackPressed();
//        }
    }

    private boolean computeWindowSizeClasses() {
        WindowMetrics metrics = WindowMetricsCalculator.getOrCreate()
                .computeCurrentWindowMetrics(requireActivity());
        float widthDp = metrics.getBounds().width() /
                getResources().getDisplayMetrics().density;
        return widthDp >= 840f;
    }

    private void addToFavourite() {
        String saveCurrentDate, saveCurrentTime;

        Calendar calForDate;
        calForDate = Calendar.getInstance();

        SimpleDateFormat currentDate = new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault());
        saveCurrentDate = currentDate.format(calForDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss Z", Locale.getDefault());
        saveCurrentTime = currentTime.format(calForDate.getTime());

        final DatabaseReference cartListRef = FirebaseDatabase.getInstance().getReference().child("Fav List1");

        final HashMap<String, Object> cartMap = new HashMap<>();
        cartMap.put("productId", productID);
        cartMap.put("productName", ProductName.getText().toString());
        cartMap.put("productPrice", ProductPrice.getText().toString());
        cartMap.put("rent", ProductRent.getText().toString());
        cartMap.put("ProductSalePrice", ProductSalePrice.getText().toString());
        cartMap.put("ProductDescription", ProductDescription.getText().toString());
        cartMap.put("date", saveCurrentDate);
        cartMap.put("time", saveCurrentTime);
        cartMap.put("quantity", numberButton.getNumber());
        cartMap.put("discount", "");
        cartMap.put("ifDiscounted", ifDiscounted);
        cartMap.put("image", imageString);

        cartListRef.child("User View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                .child(productID)
                .updateChildren(cartMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            cartListRef.child("Admin View").child(Prevalent.currentOnlineUser.getUsername()).child("Products")
                                    .child(productID)
                                    .updateChildren(cartMap)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Snackbar snackbar = Snackbar.make(HomeActivity.drawer_layout, "Product added to favourite's", Snackbar.LENGTH_SHORT);
                                                snackbar.setAction("View", c -> {
                                                    snackbar.dismiss();
                                                    requireActivity().getSupportFragmentManager().beginTransaction()
                                                            .replace(R.id.parentContainer, new CartFragment2())
                                                            .commit();

                                                });
                                                snackbar.show();
                                            }
                                        }
                                    });
                        }
                    }
                });

    }
}