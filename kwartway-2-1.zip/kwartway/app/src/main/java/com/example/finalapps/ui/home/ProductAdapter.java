package com.example.finalapps.ui.home;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalapps.Interface.ItemClickListener;
import com.example.finalapps.Model.Products;
import com.example.finalapps.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.squareup.picasso.Picasso;

import java.util.List;

class ProductAdapter extends ListAdapter<Products,ProductAdapter.ProductViewHolder> {

    private ItemClickListener listener = null;

    protected ProductAdapter() {
        super(new DiffCb());
    }


    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_items_layout, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        holder.bind(getItem(position));
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {
        public TextView txtProductName, txtProductDescription, txtProductPrice, txtProductRent, txtProductSalePrice, txtProductId;
        public ImageView imageView, favouriteImageView;
        public LinearLayout favLayout;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.product_image);
            txtProductName = (TextView) itemView.findViewById(R.id.product_name);
            txtProductPrice = (TextView) itemView.findViewById(R.id.product_price);
            txtProductRent = (TextView) itemView.findViewById(R.id.product_rent_price);
            txtProductSalePrice = (TextView) itemView.findViewById(R.id.product_sale_price);
            txtProductDescription = (TextView) itemView.findViewById(R.id.product_description);
            favouriteImageView = itemView.findViewById(R.id.favouriteIcon);
            txtProductId = itemView.findViewById(R.id.productId);
            favLayout = itemView.findViewById(R.id.favLayout);

            itemView.setOnClickListener(view -> {
                if (listener == null) return;
                listener.onClick(getItem(getAdapterPosition()));
            });
            favLayout.setOnClickListener(view -> {
                if (listener == null) return;
                listener.fabClick(getItem(getAdapterPosition()));
            });
        }

        @SuppressLint("SetTextI18n")
        public void bind(Products item) {
            txtProductName.setText(item.getName());
//          txtProductDescription.setText(model.getDescription());
            Picasso.get().load(item.getImage()).into(imageView);
            txtProductId.setText(item.getProductId());
            txtProductRent.setText(item.getRent() + "$ Rent");
            if (item.isIfDiscounted()) {
                txtProductPrice.setText(item.getPrice() + "$ Price");
                txtProductSalePrice.setText(item.getSalePrice() + "$ OnSale");
            } else {
                txtProductSalePrice.setVisibility(View.GONE);
                txtProductPrice.setText(item.getPrice() + "$ Price");
                txtProductPrice.setBackgroundResource(0);
            }
        }
    }

    public void setItemClickListener(ItemClickListener listener) {
        this.listener = listener;
    }

    static class DiffCb extends DiffUtil.ItemCallback<Products>{

        @Override
        public boolean areItemsTheSame(@NonNull Products oldItem, @NonNull Products newItem) {
            try {
                return oldItem.getProductId().equals(newItem.getProductId());
            }catch (Exception e){
                e.printStackTrace();
                return false;
            }
        }

        @Override
        public boolean areContentsTheSame(@NonNull Products oldItem, @NonNull Products newItem) {
            return oldItem.equals(newItem);
        }
    }
}