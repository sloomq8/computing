package com.example.finalapps.ViewHolder;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalapps.Model.Products;
import com.example.finalapps.ProductDetailsActivity;
import com.example.finalapps.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CategorySingleProductAdapter extends RecyclerView.Adapter<CategorySingleProductAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<Products> productList;
    private String type;

    public CategorySingleProductAdapter(Context context, ArrayList<Products> productList, String type) {
        this.context = context;
        this.productList = productList;
        this.type = type;
    }

    @NonNull
    @Override
    public CategorySingleProductAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.single_category_items_view_layout, parent, false);
        return new CategorySingleProductAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategorySingleProductAdapter.MyViewHolder holder, int position) {
        final Products products=productList.get(position);
        holder.pName.setText(products.getName());
        Picasso.get().load(products.getImage()).into(holder.pImage);
        holder.pPrice.setText(products.getPrice()+"$");
        holder.pSalePrice.setText(products.getSalePrice()+"$ OnSale");
        holder.pDescription.setText(products.getDescription());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(v.getContext(), ProductDetailsActivity.class);
                i.putExtra("productId",products.getProductId());
                v.getContext().startActivity(i);
            }
        });
        if(!products.isIfDiscounted())
        {
            holder.pPrice.setText(products.getPrice()+"$ Price");
            holder.pPrice.setBackgroundResource(0);
            holder.pSalePrice.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView pName,pPrice,pSalePrice,pDescription;
        ImageView pImage;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            pName=itemView.findViewById(R.id.sc_item_product_name);
            pImage=itemView.findViewById(R.id.sc_item_product_image);
            pPrice=itemView.findViewById(R.id.sc_item_product_price);
            pSalePrice=itemView.findViewById(R.id.sc_item_product_sale_price);
            pDescription=itemView.findViewById(R.id.sc_item_product_description);
        }


    }
}
