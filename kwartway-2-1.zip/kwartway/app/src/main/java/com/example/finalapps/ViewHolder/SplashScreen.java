package com.example.finalapps.ViewHolder;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalapps.MainActivity;
import com.example.finalapps.R;


public class SplashScreen extends AppCompatActivity {

    MediaPlayer player;

    private Handler handler = null;
    private Runnable runnable = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //  player = MediaPlayer.create(this,R.raw.tone);


        handler = new Handler(Looper.getMainLooper());
        runnable = () -> {
            Intent mainIntent = new Intent(SplashScreen.this, MainActivity.class);
            SplashScreen.this.startActivity(mainIntent);
            finish();
        };
        handler.postDelayed(runnable, 3000);


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacks(runnable);
        }
    }
}