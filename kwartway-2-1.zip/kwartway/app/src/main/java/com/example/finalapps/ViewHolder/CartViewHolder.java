package com.example.finalapps.ViewHolder;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalapps.Interface.ItemClickListener;
import com.example.finalapps.R;

public class CartViewHolder extends RecyclerView.ViewHolder {
    public TextView txtProductName, txtProductPrice, txtProductRent, txtProductQuantity;
    public ItemClickListener itemClickListener;
    public ImageView cartImage;

    public ImageView editImageView, deleteImageView;
    public ImageButton deleteButton;

    public CartViewHolder(@NonNull View itemView) {
        super(itemView);
        cartImage = itemView.findViewById(R.id.cart_product_image);
        txtProductName = itemView.findViewById(R.id.cart_product_name);
        txtProductPrice = itemView.findViewById(R.id.cart_product_price);
        txtProductRent = itemView.findViewById(R.id.cart_product_rent);
        txtProductQuantity = itemView.findViewById(R.id.cart_product_qty);
        deleteButton = itemView.findViewById(R.id.imageButton);

        itemView.setOnClickListener(v -> {
//            itemClickListener.onClick();
        });
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
}
